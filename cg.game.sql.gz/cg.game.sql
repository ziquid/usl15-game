-- MySQL dump 10.13  Distrib 5.7.29, for macos10.14 (x86_64)
--
-- Host: 127.0.0.1    Database: cg_game
-- ------------------------------------------------------
-- Server version	5.7.29-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `actions`
--

DROP TABLE IF EXISTS `actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_effects` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `preposition` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'at',
  `cost` int(11) NOT NULL DEFAULT '1',
  `values_cost` int(11) NOT NULL DEFAULT '0',
  `clan_values_cost` int(11) NOT NULL DEFAULT '0',
  `required_level` int(11) NOT NULL DEFAULT '0',
  `fkey_staff_id` int(11) NOT NULL DEFAULT '0',
  `fkey_equipment_id` int(11) NOT NULL DEFAULT '0',
  `fkey_equipment_2_id` int(11) NOT NULL DEFAULT '0',
  `need_clan` tinyint(1) NOT NULL DEFAULT '0',
  `need_no_clan` tinyint(1) NOT NULL DEFAULT '0',
  `need_clan_leader` tinyint(1) NOT NULL DEFAULT '0',
  `need_elected_official` tinyint(1) NOT NULL DEFAULT '0',
  `need_specific_elected_official` int(11) NOT NULL DEFAULT '0',
  `need_specific_elected_official_or_higher` int(11) NOT NULL DEFAULT '0',
  `need_specific_official_group` int(11) NOT NULL DEFAULT '0',
  `need_no_elected_official` tinyint(1) NOT NULL DEFAULT '0',
  `target` enum('officials','officials_type_1','officials_type_2','party','clan','wall','wall_no_official','neighborhood','neighborhood_higher_than_you_but_still_debateable','neighborhood_no_official_not_home','neighborhood_not_met','none','neighborhood_officials') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `influence_change` int(11) NOT NULL DEFAULT '0',
  `rating_change` float NOT NULL DEFAULT '0',
  `values_change` int(11) NOT NULL DEFAULT '0',
  `actions_change` int(11) NOT NULL DEFAULT '0',
  `neighborhood_rating_change` decimal(5,2) NOT NULL DEFAULT '0.00',
  `major_action` tinyint(1) NOT NULL DEFAULT '0',
  `competency_enhanced_1` int(11) NOT NULL DEFAULT '0',
  `competency_enhanced_2` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fkey_staff_id` (`fkey_staff_id`),
  KEY `fkey_equipment_id` (`fkey_equipment_id`),
  KEY `need_specific_elected_official` (`need_specific_elected_official`),
  KEY `need_specific_official_group` (`need_specific_official_group`),
  KEY `competency_enhanced_1` (`competency_enhanced_1`),
  KEY `competency_enhanced_2` (`competency_enhanced_2`),
  KEY `fkey_equipment_2_id` (`fkey_equipment_2_id`),
  KEY `need_specific_elected_official_or_higher` (`need_specific_elected_official_or_higher`),
  CONSTRAINT `actions_ibfk_3` FOREIGN KEY (`competency_enhanced_1`) REFERENCES `competencies` (`id`),
  CONSTRAINT `actions_ibfk_4` FOREIGN KEY (`competency_enhanced_2`) REFERENCES `competencies` (`id`),
  CONSTRAINT `actions_ibfk_5` FOREIGN KEY (`fkey_staff_id`) REFERENCES `staff` (`id`),
  CONSTRAINT `actions_ibfk_6` FOREIGN KEY (`fkey_equipment_id`) REFERENCES `equipment` (`id`),
  CONSTRAINT `actions_ibfk_7` FOREIGN KEY (`fkey_equipment_2_id`) REFERENCES `equipment` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actions`
--

LOCK TABLES `actions` WRITE;
/*!40000 ALTER TABLE `actions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `actions` VALUES (1,1,'Eat some food','Delicious!&nbsp; You gain a boost of Energy.','','',1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,'none',0,0,0,0,0.00,0,0,0),(2,1,'Start your own clan','Create your own clan and gain +1 energy every 5 minutes.  This clan can have up to 20 members.','','',5,0,0,0,0,6,0,0,1,0,0,0,0,0,0,'none',0,0,0,0,0.00,0,0,0),(3,1,'Join a clan','Join an existing clan and gain +1 energy every 5 minutes.&nbsp; You must know the three-letter clan ID.','','',1,25,0,0,0,0,0,0,1,0,0,0,0,0,0,'none',25,0,0,0,0.00,0,0,0),(4,1,'Leave your clan','Renounce your membership in the %subclan clan.','','',5,100,0,0,0,0,0,1,0,0,0,0,0,0,0,'none',-100,0,0,0,0.00,0,0,0),(5,1,'Remove a clan member','Remove a person\'s membership from the %subclan clan.','','named',1,0,0,0,0,0,0,1,0,1,0,0,0,0,0,'clan',-250,0,0,0,0.00,0,0,0),(6,1,'Change clan leadership','Name a new leader of your clan.','','to',20,10000,0,0,0,0,0,0,0,1,0,0,0,0,0,'clan',0,0,0,0,0.00,0,0,0),(7,1,'Change clan rules','Edit the rules of your clan.','','',1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,'none',0,0,0,0,0.00,0,0,0),(8,1,'Give a little to a clan member','Give a clan member with a need a little %value.','','named',1,100,0,0,0,0,0,1,0,0,0,0,0,0,0,'clan',0,0,80,0,0.00,0,0,0),(9,1,'Take a census','List all active players in your region.','','',5,500,0,0,0,0,0,0,0,0,0,0,0,5,0,'none',0,0,0,0,0.00,0,0,0),(10,1,'Stone an official','Nothing like a good old-fashioned stoning to bring people together.','','named',1,0,0,0,0,16,0,0,0,0,0,0,0,0,1,'officials',-20,0,0,0,0.02,0,0,0),(11,1,'Spread gossip','Whisper secrets about your opponents... does it matter if they are true or not?','','about',1,10,0,0,0,0,0,0,0,0,0,0,0,0,1,'officials',0,-0.1,0,0,-0.01,0,0,0),(12,1,'Run someone out of the region','Send a player who is not an elected official back to their home neighborhood.  The cost is 1/3 Action per level of the player (max 25 Action) and 1000 %value per level (no max).','','named',0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,'',0,0,0,0,0.03,0,0,0),(13,1,'Pray','so that you can get closer to God.','','',4,200,0,0,0,0,0,0,0,0,0,0,0,0,0,'none',0,0,0,0,0.05,0,0,0),(14,1,'Check for stoning','Has anyone been throwing rocks in your region?&nbsp; Find out.','','',8,5000,0,0,0,0,0,0,0,0,0,0,0,3,0,'none',0,0,0,0,-0.01,0,0,0),(15,1,'Check for fasting and prayer','Has anyone been fasting in your region?&nbsp; Find out.','','',10,7000,0,0,0,0,0,0,0,0,0,0,0,2,0,'none',0,0,0,0,-0.02,0,0,0),(16,0,'Bear Testimony','Placeholder -- doesn\'t do anything','','at',1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'none',0,0,0,0,0.00,0,0,0),(17,1,'Disinherit','Remove a person from your family.&nbsp; Costs 1 Action per level of the user.&nbsp; Removes 10% of their influence and aides.','','named',0,25000,0,0,0,0,0,0,0,0,0,0,0,7,0,'party',0,0,0,0,0.00,1,0,0),(18,1,'Street Preaching','Expound your beliefs to anyone who will listen.','','to',3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'neighborhood_not_met',50,0,0,0,0.03,0,0,0),(19,0,'Give luck to a clan member','Placeholder','','named',1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'none',0,0,0,0,0.00,0,0,0),(20,1,'Eavesdrop','Has anyone been gossipping about you in the past 24 hours?&nbsp; Find out.','','',12,10000,0,0,0,0,0,0,0,0,0,0,0,0,0,'none',0,0,0,0,0.00,0,0,0),(21,0,'Count your votes','Placeholder','','at',1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'none',0,0,0,0,0.00,0,0,0),(22,1,'Get challenge results','See detailed results for the last five times someone challenged you for an office.','','',5,3000,0,0,0,0,0,0,0,0,0,0,0,0,0,'none',0,0,0,0,0.00,0,0,0),(23,1,'Give to a clan member','Give a clan member with a need some of your Action points.','','named',10,5000,0,0,0,0,0,1,0,0,0,0,0,0,0,'clan',0,0,0,8,0.01,0,0,0),(24,0,'Give a Gift','to the Savior of the World.','','',2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'none',0,0,0,0,0.02,1,0,0),(25,1,'Support your local official','Show your support for the policies enacted by your local official.','','named',1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,'officials_type_1',10,0.01,0,0,0.02,0,0,0),(26,1,'Give a small magnanimous gesture','Set aside some of your %value for your followers.','','to',1,1000,0,0,0,0,0,0,0,0,1,0,0,0,0,'wall_no_official',0,0.1,750,0,-0.01,0,0,0),(27,1,'Check for gifts','See who has been kind enough to give you gifts in the past 24 hours.','','',4,3000,0,0,0,0,0,0,0,0,0,0,0,0,0,'none',0,0,0,0,-0.01,0,0,0),(28,1,'Check for stoning','Has anyone been throwing rocks in your region?&nbsp; Find out.','','',12,10000,0,0,0,0,0,0,0,0,0,1,0,0,0,'none',0,0,0,0,-0.01,0,0,0),(29,1,'Pick roses','There are %roses roses in this region.&nbsp; Pick one.','','',4,100,0,0,0,0,0,0,0,0,0,0,0,0,0,'none',0,0,0,0,0.00,0,0,0),(30,1,'Dance in the streets','with your roses, inviting all of your neighbors to enjoy themselves.&nbsp; Uses 8 roses.','','',8,800,0,0,0,31,0,0,0,0,0,0,0,0,0,'none',0,0,0,0,-0.16,0,0,0),(31,1,'Launder some %value','Use your connections with Merchants to transfer assets to another player.','','to',10,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'neighborhood',0,0,0,0,-0.02,1,0,0),(32,1,'Fast and pray','so that you can get closer to God.','','',7,2000,0,0,0,0,0,0,0,0,0,0,0,0,0,'none',0,0,0,0,0.10,0,0,0),(33,1,'Create a sign','Place a sign for everyone in your region to see.','','stating',5,25000,0,0,0,0,0,0,0,0,0,1,0,0,0,'none',0,0,0,0,-0.05,0,0,0);
/*!40000 ALTER TABLE `actions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `bank_account_transactions`
--

DROP TABLE IF EXISTS `bank_account_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank_account_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fkey_users_id` int(11) NOT NULL,
  `fkey_bank_accounts_id` int(11) NOT NULL,
  `transaction_type` enum('deposit','withdrawal') COLLATE utf8mb4_unicode_ci NOT NULL,
  `orig_balance` bigint(20) NOT NULL,
  `fkey_account_values_id` int(11) NOT NULL,
  `transaction_amount` bigint(20) NOT NULL,
  `fkey_transaction_values_id` int(11) NOT NULL,
  `account_currency_strength` decimal(3,2) NOT NULL,
  `transaction_currency_strength` decimal(3,2) NOT NULL,
  `account_currency_amount` bigint(20) NOT NULL,
  `fee_percentage` int(11) NOT NULL,
  `fee_amount` bigint(20) NOT NULL,
  `net_transaction_amount` bigint(20) NOT NULL,
  `ending_balance` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `account_number` (`fkey_bank_accounts_id`),
  KEY `account_currency` (`fkey_account_values_id`),
  KEY `transaction_currency` (`fkey_transaction_values_id`),
  CONSTRAINT `bank_account_transactions_ibfk_4` FOREIGN KEY (`fkey_bank_accounts_id`) REFERENCES `bank_accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bank_account_transactions_ibfk_5` FOREIGN KEY (`fkey_account_values_id`) REFERENCES `values` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bank_account_transactions_ibfk_6` FOREIGN KEY (`fkey_transaction_values_id`) REFERENCES `values` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank_account_transactions`
--

LOCK TABLES `bank_account_transactions` WRITE;
/*!40000 ALTER TABLE `bank_account_transactions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `bank_account_transactions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `bank_accounts`
--

DROP TABLE IF EXISTS `bank_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp_opened` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `timestamp_closed` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `transaction_lock` int(1) NOT NULL DEFAULT '0',
  `fkey_users_id` int(11) NOT NULL,
  `account_number` int(11) NOT NULL,
  `password` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `balance` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fkey_users_id` (`fkey_users_id`),
  CONSTRAINT `bank_accounts_ibfk_2` FOREIGN KEY (`fkey_users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank_accounts`
--

LOCK TABLES `bank_accounts` WRITE;
/*!40000 ALTER TABLE `bank_accounts` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `bank_accounts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `buildings`
--

DROP TABLE IF EXISTS `buildings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buildings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'is this building active?',
  `name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_system` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'system buildings can only be placed by game admins',
  `groundbreaking_cost` int(11) NOT NULL DEFAULT '50000' COMMENT 'how much to start construction',
  `daily_cost` int(11) NOT NULL DEFAULT '500' COMMENT 'how much to keep it running each day, per level',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buildings`
--

LOCK TABLES `buildings` WRITE;
/*!40000 ALTER TABLE `buildings` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `buildings` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `challenge_history`
--

DROP TABLE IF EXISTS `challenge_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `challenge_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `type` enum('debate','egging','election','gift','gossip','planting') COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkey_from_users_id` int(11) NOT NULL,
  `fkey_to_users_id` int(11) DEFAULT NULL,
  `fkey_neighborhoods_id` int(11) NOT NULL,
  `fkey_elected_positions_id` int(11) NOT NULL,
  `won` tinyint(1) NOT NULL,
  `desc_short` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc_long` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fkey_from_users_id` (`fkey_from_users_id`),
  KEY `fkey_to_users_id` (`fkey_to_users_id`),
  KEY `fkey_neighborhoods_id` (`fkey_neighborhoods_id`),
  KEY `fkey_elected_positions_id` (`fkey_elected_positions_id`),
  KEY `type` (`type`),
  CONSTRAINT `challenge_history_ibfk_5` FOREIGN KEY (`fkey_from_users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `challenge_history_ibfk_6` FOREIGN KEY (`fkey_to_users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `challenge_history_ibfk_7` FOREIGN KEY (`fkey_neighborhoods_id`) REFERENCES `neighborhoods` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `challenge_history`
--

LOCK TABLES `challenge_history` WRITE;
/*!40000 ALTER TABLE `challenge_history` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `challenge_history` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `challenge_messages`
--

DROP TABLE IF EXISTS `challenge_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `challenge_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fkey_users_from_id` int(11) NOT NULL,
  `fkey_users_to_id` int(11) NOT NULL,
  `fkey_neighborhoods_id` int(11) NOT NULL DEFAULT '0',
  `message` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fkey_users_from_id` (`fkey_users_from_id`),
  KEY `fkey_users_to_id` (`fkey_users_to_id`),
  KEY `fkey_neighborhoods_id` (`fkey_neighborhoods_id`),
  CONSTRAINT `challenge_messages_ibfk_1` FOREIGN KEY (`fkey_users_from_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `challenge_messages_ibfk_2` FOREIGN KEY (`fkey_users_to_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `challenge_messages`
--

LOCK TABLES `challenge_messages` WRITE;
/*!40000 ALTER TABLE `challenge_messages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `challenge_messages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `clan_equipment_ownership`
--

DROP TABLE IF EXISTS `clan_equipment_ownership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clan_equipment_ownership` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkey_equipment_id` int(11) NOT NULL,
  `fkey_clans_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fkey_equipment_id` (`fkey_equipment_id`),
  KEY `fkey_clans_id` (`fkey_clans_id`),
  CONSTRAINT `clan_equipment_ownership_ibfk_1` FOREIGN KEY (`fkey_equipment_id`) REFERENCES `equipment` (`id`) ON DELETE CASCADE,
  CONSTRAINT `clan_equipment_ownership_ibfk_2` FOREIGN KEY (`fkey_clans_id`) REFERENCES `clans` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clan_equipment_ownership`
--

LOCK TABLES `clan_equipment_ownership` WRITE;
/*!40000 ALTER TABLE `clan_equipment_ownership` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `clan_equipment_ownership` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `clan_members`
--

DROP TABLE IF EXISTS `clan_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clan_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkey_clans_id` int(11) NOT NULL,
  `fkey_users_id` int(11) NOT NULL,
  `is_clan_leader` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fkey_clans_id` (`fkey_clans_id`),
  KEY `fkey_users_id` (`fkey_users_id`),
  CONSTRAINT `clan_members_ibfk_3` FOREIGN KEY (`fkey_clans_id`) REFERENCES `clans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `clan_members_ibfk_4` FOREIGN KEY (`fkey_users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clan_members`
--

LOCK TABLES `clan_members` WRITE;
/*!40000 ALTER TABLE `clan_members` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `clan_members` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `clan_messages`
--

DROP TABLE IF EXISTS `clan_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clan_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fkey_users_from_id` int(11) NOT NULL,
  `fkey_users_to_id` int(11) NOT NULL,
  `fkey_neighborhoods_id` int(11) NOT NULL,
  `is_announcement` tinyint(1) NOT NULL DEFAULT '0',
  `message` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fkey_users_from_id` (`fkey_users_from_id`),
  KEY `fkey_users_to_id` (`fkey_users_to_id`),
  KEY `fkey_neighborhoods_id` (`fkey_neighborhoods_id`),
  CONSTRAINT `clan_messages_ibfk_1` FOREIGN KEY (`fkey_users_from_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `clan_messages_ibfk_2` FOREIGN KEY (`fkey_neighborhoods_id`) REFERENCES `clans` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clan_messages`
--

LOCK TABLES `clan_messages` WRITE;
/*!40000 ALTER TABLE `clan_messages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `clan_messages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `clans`
--

DROP TABLE IF EXISTS `clans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `acronym` char(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prestige` int(11) NOT NULL DEFAULT '0',
  `wins` int(11) NOT NULL DEFAULT '0',
  `losses` int(11) NOT NULL DEFAULT '0',
  `money` int(11) NOT NULL DEFAULT '0',
  `attack` int(11) NOT NULL DEFAULT '0',
  `defense` int(11) NOT NULL DEFAULT '0',
  `rules` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `acronym` (`acronym`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clans`
--

LOCK TABLES `clans` WRITE;
/*!40000 ALTER TABLE `clans` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `clans` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `competencies`
--

DROP TABLE IF EXISTS `competencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `competencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `competencies`
--

LOCK TABLES `competencies` WRITE;
/*!40000 ALTER TABLE `competencies` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `competencies` VALUES (0,'No Competency',0),(1,'investor',1),(2,'lost',2),(3,'quester',1),(4,'second-mile saint',1),(5,'looter',1),(6,'quest finisher',2),(7,'too tired',1),(8,'hole in pockets',1),(9,'friendless',1),(10,'quest groupie',3),(11,'people person',1),(12,'introspective',1),(13,'talkative',1),(14,'pruner',1),(15,'silent cal',1),(16,'uncouth',1),(17,'driver',1),(18,'clean',1),(19,'challenger',1),(20,'defender',1),(21,'builder',1),(22,'selfless',2),(23,'saver',1),(24,'green thumb',1),(25,'vandal',1),(26,'thief',1),(27,'incompetent',1),(28,'satiated',1),(29,'gossipper',1),(30,'trustworthy',1),(31,'loyal',1),(32,'helpful',1),(33,'friendly',1),(34,'courteous',1),(35,'kind',1),(36,'obedient',1),(37,'cheerful',1),(38,'thrifty',1),(39,'brave',1),(40,'reverent',1),(41,'physically strong',1),(42,'mentally awake',1),(43,'morally straight',1),(44,'drunk',2),(45,'sober',2),(46,'where the heart is',1),(47,'zombie whisperer',2),(48,'curious',2),(49,'animal husbandry',3),(50,'too busy',1),(51,'propaganda',1),(52,'disaster preparedness',1);
/*!40000 ALTER TABLE `competencies` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `elected_officials`
--

DROP TABLE IF EXISTS `elected_officials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elected_officials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fkey_elected_positions_id` int(11) DEFAULT NULL,
  `fkey_users_id` int(11) DEFAULT NULL,
  `approval_rating` float NOT NULL DEFAULT '60',
  `approval_15` float NOT NULL DEFAULT '60',
  `approval_30` float NOT NULL DEFAULT '60',
  `approval_45` float NOT NULL DEFAULT '60',
  PRIMARY KEY (`id`),
  KEY `fkey_users_id` (`fkey_users_id`),
  KEY `fkey_elected_positions_id` (`fkey_elected_positions_id`),
  CONSTRAINT `elected_officials_ibfk_1` FOREIGN KEY (`fkey_elected_positions_id`) REFERENCES `elected_positions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `elected_officials_ibfk_2` FOREIGN KEY (`fkey_users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elected_officials`
--

LOCK TABLES `elected_officials` WRITE;
/*!40000 ALTER TABLE `elected_officials` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `elected_officials` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `elected_positions`
--

DROP TABLE IF EXISTS `elected_positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elected_positions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` int(11) NOT NULL DEFAULT '1',
  `group` int(11) NOT NULL DEFAULT '1',
  `energy_bonus` int(11) NOT NULL DEFAULT '0',
  `min_level` int(11) NOT NULL DEFAULT '0',
  `max_level` int(11) NOT NULL DEFAULT '200',
  `limit_per_hood` int(11) NOT NULL DEFAULT '0',
  `limit_per_game` int(11) NOT NULL DEFAULT '0',
  `can_broadcast_to_party` tinyint(1) NOT NULL DEFAULT '0',
  `gets_new_user_notifications` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'gets message notifications of new users?',
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `type_2` (`type`),
  KEY `group` (`group`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elected_positions`
--

LOCK TABLES `elected_positions` WRITE;
/*!40000 ALTER TABLE `elected_positions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elected_positions` VALUES (1,'Chief Priest','',1,1,13,75,105,0,0,1,0),(2,'Elder','',1,2,8,60,85,0,0,1,0),(3,'Elder','',1,2,8,60,85,0,0,1,0),(4,'Elder','',1,2,8,60,85,0,0,1,0),(5,'Priest','',1,3,5,40,65,0,0,1,0),(6,'Priest','',1,3,5,40,65,0,0,0,0),(7,'Priest','',1,3,5,40,65,0,0,0,0),(8,'Priest','',1,3,5,40,65,0,0,0,0),(9,'Teacher','',1,4,3,20,45,0,0,1,0),(10,'Scribe','',1,5,2,0,25,0,0,1,0),(11,'Scribe','',1,5,1,0,25,0,0,0,0),(12,'Scribe','',1,5,1,0,25,0,0,0,0),(13,'Scribe','',1,5,1,0,25,0,0,0,0),(14,'Scribe','',1,5,1,0,25,0,0,0,0),(15,'Scribe','',1,5,1,0,25,0,0,0,0),(16,'Tribal Elder','',2,6,21,100,125,0,0,0,0),(17,'Tribal Elder','',2,6,21,100,125,0,0,0,0),(18,'Tribal Elder','',2,6,21,100,125,0,0,0,0),(19,'Tribal Chieftain','',2,7,34,120,145,0,0,0,0),(20,'Tribal Chieftain','',2,7,34,120,145,0,0,0,0),(21,'Teacher','',1,4,2,20,45,0,0,0,0),(22,'Teacher','',1,4,2,20,45,0,0,0,0),(23,'Teacher','',1,4,2,20,45,0,0,0,0);
/*!40000 ALTER TABLE `elected_positions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `equipment`
--

DROP TABLE IF EXISTS `equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'm',
  `action_verb` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkey_neighborhoods_id` int(11) NOT NULL,
  `fkey_values_id` int(11) NOT NULL,
  `required_level` int(11) NOT NULL,
  `quantity_limit` int(11) NOT NULL DEFAULT '0',
  `is_loot` tinyint(1) NOT NULL DEFAULT '0',
  `can_sell` tinyint(1) NOT NULL DEFAULT '1',
  `price` int(11) NOT NULL,
  `price_increase` int(11) NOT NULL,
  `income` int(11) NOT NULL DEFAULT '0',
  `upkeep` int(11) NOT NULL DEFAULT '0',
  `energy_bonus` int(11) NOT NULL DEFAULT '0',
  `energy_increase` int(11) NOT NULL DEFAULT '0',
  `initiative_bonus` int(11) NOT NULL DEFAULT '0',
  `endurance_bonus` int(11) NOT NULL DEFAULT '0',
  `elocution_bonus` int(11) NOT NULL DEFAULT '0',
  `clan_size` int(11) NOT NULL DEFAULT '0',
  `speed_increase` int(11) NOT NULL DEFAULT '0',
  `chance_of_loss` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fkey_neighborhoods_id` (`fkey_neighborhoods_id`),
  KEY `fkey_values_id` (`fkey_values_id`),
  CONSTRAINT `equipment_ibfk_1` FOREIGN KEY (`fkey_neighborhoods_id`) REFERENCES `neighborhoods` (`id`),
  CONSTRAINT `equipment_ibfk_2` FOREIGN KEY (`fkey_values_id`) REFERENCES `values` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment`
--

LOCK TABLES `equipment` WRITE;
/*!40000 ALTER TABLE `equipment` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `equipment` VALUES (0,0,'Nothing','','m','',0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0),(1,1,'Dried Fruit, Bread, and Grains','suitable for storage for a long trip into the desert.','m','',0,0,1,0,0,1,30,3,0,0,0,0,0,0,0,0,0,0),(2,1,'Clothing','loosely fitting but with long sleeves and legs, to keep away the sun and sand.','m','',0,0,2,0,0,1,50,5,0,0,0,0,0,0,0,0,0,0),(3,1,'A small tent','suitable for the dwelling of a small family in the desert.&nbsp; Each small tent allows you to add four people to your clan.','m','',0,0,3,30,0,1,150,15,0,5,0,0,0,0,0,4,0,0),(4,1,'Stone Knife','The most rudimentary weapon.','m','',0,0,4,0,0,1,50,5,0,0,0,0,1,0,1,0,0,25),(5,1,'Leather Shield','The most rudimentary shield.','m','',0,0,5,0,0,1,80,8,0,0,0,0,0,1,2,0,0,10),(6,1,'Large Tent','A tent large enough to hold an extended family, this tent allows you to create a clan of 20 members.','m','',0,0,0,1,1,0,0,0,0,0,0,1,0,0,0,20,0,0),(7,1,'Wooden Knife','Sharper than a rock and a little sturdier.','m','',0,0,10,0,0,1,150,15,0,0,0,0,3,0,3,0,0,12),(8,1,'Wooden Shield','Sturdier than a leather shield.','m','',0,0,15,0,0,1,300,30,0,0,0,0,0,3,5,0,0,4),(9,1,'A Testimony of Your Father','Now you know that what your father says is true.','m','',0,0,0,0,1,0,0,0,0,0,0,0,10,0,0,0,0,5),(10,1,'An Errand from the Lord','God has asked you to do something.','m','',0,0,0,0,1,0,0,0,0,0,0,0,0,10,0,0,0,0),(11,1,'Rope','Useful for tying things, or people, up in knots.','m','',0,0,20,0,0,1,600,60,0,2,0,0,5,0,10,0,0,5),(12,1,'Wooden Sword','Not sturdy or as sharp as others, but able to parry and thrust better than a smaller blade.','m','',0,0,25,0,0,1,1000,100,0,5,0,0,8,5,2,0,0,10),(13,1,'Riches','from your old home in Jerusalem.','m','',0,0,0,0,1,1,1000,100,100,0,0,0,0,0,10,0,0,1),(14,1,'Sword of Laban','... [T]he hilt thereof was of pure gold, and the workmanship thereof was exceedingly fine, and I saw that the blade thereof was of the most precious steel.','m','',0,0,0,0,1,0,0,0,0,0,0,0,80,0,0,0,0,1),(15,1,'Clothes of Laban','Wearing Laban\'s clothing allows you to pretend to be him.','m','',0,0,0,0,1,0,0,0,0,0,0,0,0,0,80,0,0,1),(16,1,'Rock','Hard and pointy.','m','Stone',0,0,13,101,0,1,25,1,0,0,0,0,1,0,0,0,0,100),(17,1,'The Brass Plates','containing the record of the Jews and also a genealogy of your forefathers.','m','',0,0,0,0,1,0,0,0,0,0,0,0,0,80,0,0,0,1),(18,1,'A Successfully Completed Quest','You have done what God asked you to do.','m','',0,0,0,0,1,0,0,0,0,0,0,0,25,25,0,0,0,3),(19,1,'A Camel Caravan','Use a caravan to help you move from region to region.','m','Plod',0,0,12,0,0,1,1000,100,0,0,0,0,0,0,0,0,5,10),(20,1,'Donkey','Gets you from point A to point B, although somewhat uncomfortably.','m','Bump',0,0,24,0,0,1,5000,500,0,0,0,0,0,0,0,0,10,10),(21,1,'Chariot','Ho!&nbsp; Master the roadways with this chariot.','m','Ride',0,0,36,0,0,1,20000,2000,0,0,0,0,0,0,0,0,15,10),(22,1,'Racing Camel','Who says camels are slow?&nbsp; These are bred for speed!','m','Ride',14,0,48,0,0,1,70000,7000,0,7000,0,0,0,0,0,0,20,8),(23,1,'Arabian Stallion','The pinnacle of desert travel.&nbsp; Why ride on anything less?','m','Ride',14,0,60,0,0,1,200000,20000,0,20000,0,0,0,0,0,0,25,6),(24,1,'A Second Errand from the Lord','God has again asked you to do something.','m','',0,0,0,0,1,0,0,0,0,0,0,0,40,20,10,0,0,0),(25,1,'The Trust of Ishmael','Ishmael trusts you and is willing to journey into the wilderness with you.','m','',0,0,1,0,1,0,0,0,0,0,0,0,10,40,20,0,0,0),(26,1,'Iron Knife','Cuts with the best of them.&nbsp; Necessarily sharp, for cutting food (or people).','m','',0,0,30,0,0,1,1800,180,0,10,0,0,10,0,8,0,0,1),(27,1,'Iron Shield','Protect yourself from attacks.','m','',0,0,35,0,0,1,3000,300,0,25,0,0,0,20,0,0,0,1),(28,1,'Another Successfully Completed Quest','You have successfully returned with Ishmael and his family.','m','',0,0,1,0,1,0,0,0,0,0,0,0,20,10,40,0,0,0),(29,1,'Going the Second Mile','You have done everything asked of you twice, and deserve a reward.','m','',0,0,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,0),(30,1,'Berries and Seeds','suitable for storage for a long trip into the desert.','m','',0,0,30,0,1,1,100,10,0,0,0,0,0,0,0,0,0,0),(31,1,'Roses','they look great and smell great.','m','',0,0,40,199,1,0,5000,500,0,0,0,0,0,0,0,0,0,5),(32,1,'Liahona','showing you which way to go and what to do, according to your faith.','m','',0,0,40,0,1,0,100000,10000,0,1000,0,0,120,120,120,0,0,0),(33,1,'Dagger','Made of bronze; lighter than iron and less expensive than steel.','m','',4,0,40,0,0,1,3000,300,0,30,0,0,20,2,10,0,0,1),(34,1,'Scimitar','Its curved design allows you to cut and rip with ease.','m','',4,0,45,0,0,1,5000,500,0,60,0,0,30,6,12,0,0,1),(35,1,'Bronze Shield','Use it to keep yourself from getting hurt.','m','',0,0,50,0,0,1,6000,600,0,75,0,0,1,35,2,0,0,1),(36,1,'Merchant Comprehension','You now understand how to be a merchant.','m','',0,0,34,1,1,0,100000,10000,0,2500,0,1,240,240,240,0,0,0),(37,1,'Steel Bow','Steel bow and arrows designed for hunting food.','m','',8,0,46,0,0,1,8000,800,0,80,0,0,40,0,4,0,0,4),(38,1,'Fine Steel Bow','Fine steel bow and arrows designed for hunting food.','m','',8,0,47,0,1,0,16000,1600,0,120,0,0,75,0,9,0,0,2),(39,1,'Nephi\'s Fine Steel Bow','Nephi\'s fine steel bow and arrows designed for hunting food.','m','',8,0,52,0,1,0,32000,3200,0,240,0,1,125,10,25,0,0,0),(40,1,'Sling','Useful for hurling rocks at animals.  Or people.','m','',8,0,42,0,0,1,3500,350,0,30,0,0,32,0,10,0,0,2),(41,1,'Wooden Bow','Not quite as good as a steel bow, but it gets the job done.','m','',8,0,44,0,1,1,4000,400,0,40,0,0,36,2,4,0,0,5),(42,0,'Sling of Accuracy','Useful for hurling rocks at animals.  Or people.','m','',8,0,48,0,0,1,7000,700,0,60,0,0,56,0,12,0,0,1),(43,0,'Sling of Deadly Force','Useful for hurling rocks at animals.  Or people.','m','',8,0,49,0,0,1,12000,1200,0,100,0,0,102,0,18,0,0,0),(44,1,'Faith','Belief in something true but unseen.','m','',0,0,53,0,1,0,12000,1200,0,90,0,0,60,10,30,0,0,0),(45,1,'Diligence','Willingness to act on faith.','m','',0,0,54,0,1,0,13000,1300,0,95,0,0,60,30,10,0,0,0),(46,1,'Heed','Willingness to listen to truth.','m','',0,0,55,0,1,0,14000,1400,0,100,0,0,10,60,30,0,0,0),(47,1,'Hearts','for the brave of soul and character.','m','',0,0,40,0,1,0,5000,500,0,0,0,0,0,0,20,0,0,100),(48,1,'Double Hearts','for the doubly brave of soul and character.','m','',0,0,41,0,1,0,12000,1200,0,0,0,0,5,5,35,0,0,100),(49,1,'Triple Hearts','for the triply brave of soul and character.','m','',0,0,42,0,1,0,280000,28000,0,0,0,1,500,500,3500,0,0,0),(50,1,'Lizard Skin','Can be used for carrying things, including water.','m','',0,0,11,0,1,1,200,20,0,0,0,0,1,5,0,0,0,4),(51,1,'Raw Amethyst','It\'s worth something, but with lots of work it could be worth a lot more.','m','',0,0,12,0,1,1,400,40,0,0,0,0,8,8,8,0,0,5),(52,1,'Refined Amethyst','More valuable than raw amethyst, this rock is smooth and pretty.','m','',0,0,13,0,1,1,4000,400,0,0,0,0,30,30,30,0,0,2),(53,1,'Perfect Amethyst','Refined amethyst turned into a gem of pure beauty.','m','',0,0,14,0,1,1,40000,4000,0,0,0,0,110,110,110,0,0,1),(54,1,'Tree of Life Token','Your father Lehi saw this in a dream.&nbsp; Maybe you can find out what it means.','m','',0,0,46,1,1,0,200000,2,0,1000,0,2,480,480,480,0,0,0),(55,1,'Radiant Bronze Shield','Use it to keep yourself from getting hurt, radiantly.','m','',0,0,56,0,0,1,15000,1500,0,140,0,0,10,60,5,0,0,1),(56,1,'Brilliant Bronze Shield','Use it to keep yourself from getting hurt, brilliantly.','m','',0,0,61,0,0,1,35000,3500,0,260,0,0,18,108,14,0,0,1),(57,1,'Lehi Token','You have beaten Lehi in a challenge.&nbsp; This is your reward.','m','',0,0,1,0,1,1,100,10,0,0,0,0,8,8,6,0,0,0),(58,1,'Sariah Token','You have beaten Sariah in a challenge.&nbsp; This is your reward.','m','',0,0,1,0,1,1,100,10,0,0,0,0,6,6,7,0,0,0),(59,1,'Laman Token','You have beaten Laman in a challenge.&nbsp; This is your reward.','m','',0,0,1,0,1,1,100,10,0,0,0,0,9,5,7,0,0,0),(60,1,'Lemuel Token','You have beaten Lemuel in a challenge.&nbsp; This is your reward.','m','',0,0,1,0,1,1,100,10,0,0,0,0,8,5,6,0,0,0),(61,1,'Sam Token','You have beaten Sam in a challenge.&nbsp; This is your reward.','m','',0,0,1,0,1,1,100,10,0,0,0,0,8,6,8,0,0,0),(62,1,'Nephi Token','You have beaten Nephi in a challenge.&nbsp; This is your reward.','m','',0,0,1,0,1,1,100,10,0,0,0,0,10,8,10,0,0,0),(63,1,'Zoram Token','You have beaten Zoram in a challenge.&nbsp; This is your reward.','m','',0,0,1,0,1,1,100,10,0,0,0,0,6,10,8,0,0,0);
/*!40000 ALTER TABLE `equipment` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `equipment_failure_reasons`
--

DROP TABLE IF EXISTS `equipment_failure_reasons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipment_failure_reasons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkey_equipment_id` int(11) NOT NULL,
  `message` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fkey_equipment_id` (`fkey_equipment_id`),
  CONSTRAINT `equipment_failure_reasons_ibfk_1` FOREIGN KEY (`fkey_equipment_id`) REFERENCES `equipment` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment_failure_reasons`
--

LOCK TABLES `equipment_failure_reasons` WRITE;
/*!40000 ALTER TABLE `equipment_failure_reasons` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `equipment_failure_reasons` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `equipment_ownership`
--

DROP TABLE IF EXISTS `equipment_ownership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipment_ownership` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkey_equipment_id` int(11) NOT NULL,
  `fkey_users_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `quantity_used` int(11) NOT NULL DEFAULT '0' COMMENT 'how many have been already used / consumed',
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fkey_equipment_id_2` (`fkey_equipment_id`,`fkey_users_id`),
  KEY `fkey_equipment_id` (`fkey_equipment_id`),
  KEY `fkey_users_id` (`fkey_users_id`),
  CONSTRAINT `equipment_ownership_ibfk_3` FOREIGN KEY (`fkey_equipment_id`) REFERENCES `equipment` (`id`) ON DELETE CASCADE,
  CONSTRAINT `equipment_ownership_ibfk_4` FOREIGN KEY (`fkey_users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment_ownership`
--

LOCK TABLES `equipment_ownership` WRITE;
/*!40000 ALTER TABLE `equipment_ownership` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `equipment_ownership` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `event_milestones`
--

DROP TABLE IF EXISTS `event_milestones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_milestones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `points` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_milestones`
--

LOCK TABLES `event_milestones` WRITE;
/*!40000 ALTER TABLE `event_milestones` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `event_milestones` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `event_points`
--

DROP TABLE IF EXISTS `event_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkey_users_id` int(11) NOT NULL,
  `points` int(11) NOT NULL DEFAULT '0',
  `tags` int(11) NOT NULL DEFAULT '0',
  `tagged` int(11) NOT NULL DEFAULT '0',
  `heals` int(11) NOT NULL DEFAULT '0',
  `tags_con` int(11) NOT NULL DEFAULT '0',
  `heals_con` int(11) NOT NULL DEFAULT '0',
  `last_goal_achieved` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fkey_users_id` (`fkey_users_id`),
  CONSTRAINT `event_points_ibfk_1` FOREIGN KEY (`fkey_users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_points`
--

LOCK TABLES `event_points` WRITE;
/*!40000 ALTER TABLE `event_points` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `event_points` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `favor_requests`
--

DROP TABLE IF EXISTS `favor_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `favor_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkey_favors_id` int(11) NOT NULL,
  `time_requested` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fkey_users_from_id` int(11) NOT NULL,
  `fkey_users_to_id` int(11) NOT NULL,
  `time_due` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `time_completed` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `success_expected` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fkey_favors_id` (`fkey_favors_id`),
  KEY `fkey_users_from_id` (`fkey_users_from_id`),
  KEY `fkey_users_to_id` (`fkey_users_to_id`),
  CONSTRAINT `favor_requests_ibfk_1` FOREIGN KEY (`fkey_favors_id`) REFERENCES `favors` (`id`) ON DELETE CASCADE,
  CONSTRAINT `favor_requests_ibfk_2` FOREIGN KEY (`fkey_users_from_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `favor_requests_ibfk_3` FOREIGN KEY (`fkey_users_to_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favor_requests`
--

LOCK TABLES `favor_requests` WRITE;
/*!40000 ALTER TABLE `favor_requests` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `favor_requests` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `favors`
--

DROP TABLE IF EXISTS `favors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `favors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `initiator_description` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `runner_description` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkey_required_elected_positions_id` int(11) NOT NULL DEFAULT '0',
  `fkey_required_competencies_id` int(11) NOT NULL DEFAULT '0',
  `required_competencies_level` int(11) NOT NULL DEFAULT '1',
  `fkey_enhanced_competencies_id` int(11) NOT NULL DEFAULT '0',
  `actions_cost` int(11) NOT NULL DEFAULT '1',
  `values_cost` int(11) NOT NULL,
  `runner_actions_cost` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fkey_required_elected_position` (`fkey_required_elected_positions_id`),
  KEY `fkey_required_competencies` (`fkey_required_competencies_id`),
  KEY `fkey_competencies_enhanced` (`fkey_enhanced_competencies_id`),
  CONSTRAINT `favors_ibfk_1` FOREIGN KEY (`fkey_required_elected_positions_id`) REFERENCES `elected_positions` (`id`),
  CONSTRAINT `favors_ibfk_2` FOREIGN KEY (`fkey_required_competencies_id`) REFERENCES `competencies` (`id`),
  CONSTRAINT `favors_ibfk_3` FOREIGN KEY (`fkey_enhanced_competencies_id`) REFERENCES `competencies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favors`
--

LOCK TABLES `favors` WRITE;
/*!40000 ALTER TABLE `favors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `favors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `game_defaults`
--

DROP TABLE IF EXISTS `game_defaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `game_defaults` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `game_key` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'key',
  `game_value` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'value',
  `value_type` enum('int','text','serialized','float','bool') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text' COMMENT 'type of value',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'date of latest update',
  PRIMARY KEY (`id`),
  UNIQUE KEY `game_key` (`game_key`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_defaults`
--

LOCK TABLES `game_defaults` WRITE;
/*!40000 ALTER TABLE `game_defaults` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `game_defaults` VALUES (1,'initial_hood','1','int','2020-10-05 05:14:30'),(2,'initial_user_value','Faith','text','2020-10-05 05:14:36'),(3,'welcome_page_1_speech','Hello there','text','2018-11-05 10:05:28'),(4,'welcome_page_2_speech','Get ready to become Mayor!','text','2018-11-05 10:36:01'),(5,'new_user_comm_member_msg','I am a new user who has just joined the game.  Please welcome me.','text','2018-11-05 10:38:52'),(6,'number_of_welcome_pages','2','int','2018-11-07 17:05:21'),(7,'has_quest_actions','FALSE','bool','2018-11-10 20:45:17'),(8,'must_choose_party_at_level','6','int','2018-11-12 09:51:12'),(9,'has_office_level_limits','TRUE','bool','2018-12-30 20:45:17');
/*!40000 ALTER TABLE `game_defaults` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `goals`
--

DROP TABLE IF EXISTS `goals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(48) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('actions','clan','favor','hierarch','home','increase_skills','land','quests','user') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'quests',
  `code_to_check` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `luck_bonus` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goals`
--

LOCK TABLES `goals` WRITE;
/*!40000 ALTER TABLE `goals` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `goals` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `goals_achieved`
--

DROP TABLE IF EXISTS `goals_achieved`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goals_achieved` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkey_users_id` int(11) NOT NULL,
  `fkey_goals_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fkey_users_id` (`fkey_users_id`),
  KEY `fkey_goals_id` (`fkey_goals_id`),
  CONSTRAINT `goals_achieved_ibfk_1` FOREIGN KEY (`fkey_users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `goals_achieved_ibfk_2` FOREIGN KEY (`fkey_goals_id`) REFERENCES `goals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goals_achieved`
--

LOCK TABLES `goals_achieved` WRITE;
/*!40000 ALTER TABLE `goals_achieved` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `goals_achieved` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `html_well`
--

DROP TABLE IF EXISTS `html_well`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `html_well` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `html_key` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'html key',
  `html_value` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'html value',
  `comment` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'comments, if any',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'last update',
  PRIMARY KEY (`id`),
  UNIQUE KEY `html_key` (`html_key`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='html well for basic KVP html';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `html_well`
--

LOCK TABLES `html_well` WRITE;
/*!40000 ALTER TABLE `html_well` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `html_well` VALUES (1,'tagline','&bull; Journey to the Promised Land &bull;','','2020-10-04 21:10:00'),(2,'welcome_page_1','<div class=\"welcome\">\r\n<div class=\"wise_old_man_large point\">\r\n</div>\r\n<p>You are met in a dream by an old man.</p>\r\n    <p class=\"second\">&quot;Hello.&nbsp; My name is Lehi and I have come to\r\n      tell you my story.</p>\r\n    <p class=\"second\">&quot;Six hundred years before the coming of Jesus\r\n      Christ, I was living in Jerusalem with my family when I saw a\r\n      vision.&nbsp; God showed me many things and asked me to follow his\r\n      direction.</p>\r\n    <p class=\"second\">&quot;I have come to tell you this story now.&nbsp; You\r\n      will learn the story by playing the part of my son, Nephi, who became\r\n      the leader of a great number of people.</p>\r\n    <p class=\"second\">&quot;Listen to my story and you, too, can become\r\n      great.&quot;</p>\r\n</div>','first welcome page','2020-10-04 18:56:58'),(3,'welcome_page_2','<div class=\"welcome\">\n  <div class=\"city-icon\">\n  </div>\n  <div class=\"subtitle\">\n    How to play\n  </div>\n  <ul>\n    <li>Finish missions to earn skills and influence</li>\n    <li>Cooperate and compete with other players to achieve your goals</li>\n    <li>Purchase investments and equipment to earn money and win votes</li>\n    <li>Become a city elder, political party leader, and then mayor</li>\n  </ul>\n</div>','second welcome page','2018-11-07 17:40:41'),(4,'high_chance_of_loot','<div class=\"quest-loot\">High Chance of Loot!</div>','','2018-11-12 09:40:23'),(5,'chance_of_loot','<div class=\"quest-loot\">Chance of Loot!</div>','','2018-11-12 09:40:23'),(6,'low_chance_of_loot','<div class=\"quest-loot\">Low Chance of Loot!</div>','','2018-11-12 09:40:23'),(7,'authenticate','<div class=\"speech-bubble-wrapper background-color\">\r\n  <div class=\"wise_old_man happy\">\r\n  </div>\r\n  <div class=\"speech-bubble\">\r\n  <p>Welcome back!</p>\r\n<p>\r\n  You are almost ready to continue playing!&nbsp;\r\n  Just to ensure you are the correct player, will you give me your\r\n  password?\r\n</p>\r\n<p>\r\n  If you can\'t remember it, you can e-mail <strong>zipport@ziquid.com</strong>\r\n  and we can reset it for you.\r\n</p>\r\n<div class=\"ask-name\">\r\n  <form method=get action=\"/%game/authenticate/%arg2\">\r\n    <input type=\"password\" name=\"password\" width=\"20\" maxlength=\"20\"/>\r\n    <input type=\"submit\" value=\"Submit\"/>\r\n  </form>\r\n</div>\r\n  </div>\r\n</div>','When a player needs to enter password.','2019-05-28 21:16:27'),(8,'authenticate_speech','Welcome Back!','','2019-05-28 21:16:27'),(9,'authentication_error','This game must must be accessed through an authorized client.  Please e-mail <strong>zipport@ziquid.com</strong> if you have any questions.','','2019-05-28 21:17:01');
/*!40000 ALTER TABLE `html_well` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `ip_whitelist`
--

DROP TABLE IF EXISTS `ip_whitelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ip_whitelist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `notes` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ip_whitelist`
--

LOCK TABLES `ip_whitelist` WRITE;
/*!40000 ALTER TABLE `ip_whitelist` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `ip_whitelist` VALUES (1,'50.234.30.102','2020-04-30 03:46:30','Kennesaw Inn');
/*!40000 ALTER TABLE `ip_whitelist` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `karma`
--

DROP TABLE IF EXISTS `karma`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `karma` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkey_users_id` int(11) NOT NULL,
  `text` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fkey_users_id` (`fkey_users_id`),
  CONSTRAINT `karma_ibfk_1` FOREIGN KEY (`fkey_users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `karma`
--

LOCK TABLES `karma` WRITE;
/*!40000 ALTER TABLE `karma` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `karma` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `land`
--

DROP TABLE IF EXISTS `land`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `land` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL,
  `name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkey_neighborhoods_id` int(11) NOT NULL,
  `fkey_values_id` int(11) NOT NULL,
  `required_level` int(11) NOT NULL,
  `fkey_required_competencies_id` int(11) NOT NULL,
  `required_competencies_level` int(11) NOT NULL,
  `fkey_enhanced_competencies_id` int(11) DEFAULT NULL,
  `can_sell` tinyint(1) NOT NULL DEFAULT '1',
  `price` int(11) NOT NULL,
  `price_increase` int(11) NOT NULL,
  `payout` int(11) NOT NULL,
  `type` enum('job','investment') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'job',
  PRIMARY KEY (`id`),
  KEY `fkey_neighborhoods_id` (`fkey_neighborhoods_id`),
  KEY `fkey_values_id` (`fkey_values_id`),
  KEY `fkey_required_competencies_id` (`fkey_required_competencies_id`),
  KEY `fkey_enhanced_competencies_id` (`fkey_enhanced_competencies_id`),
  CONSTRAINT `land_ibfk_1` FOREIGN KEY (`fkey_neighborhoods_id`) REFERENCES `neighborhoods` (`id`),
  CONSTRAINT `land_ibfk_2` FOREIGN KEY (`fkey_values_id`) REFERENCES `values` (`id`),
  CONSTRAINT `land_ibfk_3` FOREIGN KEY (`fkey_required_competencies_id`) REFERENCES `competencies` (`id`),
  CONSTRAINT `land_ibfk_4` FOREIGN KEY (`fkey_enhanced_competencies_id`) REFERENCES `competencies` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `land`
--

LOCK TABLES `land` WRITE;
/*!40000 ALTER TABLE `land` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `land` VALUES (0,0,'Nothing','',0,0,0,0,0,NULL,0,0,0,0,'job'),(1,1,'A camel','Great for carrying heavy loads of goods across the desert.',0,0,1,0,0,NULL,1,100,10,2,'job'),(2,1,'Locusts','Not the most appealing food in the desert, but try frying them in butter.&nbsp; Yum yum!',0,0,1,0,0,NULL,1,600,60,9,'job'),(3,1,'Lizards','Real flesh.&nbsp; Roast them up and have a feast.&nbsp; Use their skins, too!',0,0,10,0,0,NULL,1,2500,250,25,'job'),(4,1,'A pomegranate tree','Great for eating, dyeing, and full of antioxidants too.&nbsp; No wonder those desert-dwellers are healthy.',0,0,20,0,0,NULL,1,25000,2500,250,'job'),(5,1,'Sheep','They bleat and they provide wool and meat.&nbsp; What\'s not to love?',0,0,40,0,0,NULL,1,250000,25000,2000,'job'),(6,1,'An apricot tree','Delicious juice and yummy fruit.&nbsp; A great treat in the desert.',0,0,15,0,0,NULL,1,9000,900,90,'job'),(7,1,'A beehive','These little bugs have a great work ethic.&nbsp; Enjoy the sweetness that they provide.',0,0,30,0,0,NULL,1,90000,9000,900,'job'),(8,1,'A falcon','Can search many miles for prey.&nbsp; A swift and great hunter.',0,3,30,0,0,NULL,1,90000,9000,900,'job'),(9,1,'An olive tree','Full of life, the olive tree brings juice and healing oil.',1,0,15,0,0,NULL,1,9000,900,90,'job'),(10,1,'A gazelle','Fast, but if the lions like them, maybe we can use them.',0,0,50,0,0,NULL,1,900000,90000,6500,'job'),(11,1,'A goat','Meat and milk!&nbsp; What a combination!',0,0,60,0,0,NULL,1,2500000,250000,18000,'job'),(12,1,'A small trading post','Barter, buy, and sell items in your portable trading post.',0,5,30,0,0,NULL,1,90000,9000,900,'job'),(13,1,'A small oasis','Come rest your weary souls and animals at this small haven in the desert.',14,0,50,0,0,NULL,1,900000,90000,6500,'job');
/*!40000 ALTER TABLE `land` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `land_ownership`
--

DROP TABLE IF EXISTS `land_ownership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `land_ownership` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkey_land_id` int(11) NOT NULL,
  `fkey_users_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fkey_land_id_2` (`fkey_land_id`,`fkey_users_id`),
  KEY `fkey_land_id` (`fkey_land_id`),
  KEY `fkey_users_id` (`fkey_users_id`),
  CONSTRAINT `land_ownership_ibfk_3` FOREIGN KEY (`fkey_land_id`) REFERENCES `land` (`id`) ON DELETE CASCADE,
  CONSTRAINT `land_ownership_ibfk_4` FOREIGN KEY (`fkey_users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `land_ownership`
--

LOCK TABLES `land_ownership` WRITE;
/*!40000 ALTER TABLE `land_ownership` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `land_ownership` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `levels`
--

DROP TABLE IF EXISTS `levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `levels` (
  `level` int(11) NOT NULL AUTO_INCREMENT,
  `experience` int(11) NOT NULL,
  PRIMARY KEY (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `levels`
--

LOCK TABLES `levels` WRITE;
/*!40000 ALTER TABLE `levels` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `levels` VALUES (1,0),(2,6),(3,21),(4,37),(5,55),(6,75),(7,108),(8,164),(9,241),(10,342),(11,467),(12,616),(13,792),(14,995),(15,1225),(16,1485),(17,1775),(18,2098),(19,2454),(20,2843),(21,3268),(22,3729),(23,4229),(24,4771),(25,5352),(26,5978),(27,6649),(28,7365),(29,8132),(30,8950),(31,9819),(32,10742),(33,11722),(34,12762),(35,13865),(36,15031),(37,16263),(38,17564),(39,18937),(40,20385),(41,21911),(42,23518),(43,25209),(44,26990),(45,28861),(46,30828),(47,32894),(48,35062),(49,37335),(50,39719),(51,42220),(52,44841),(53,47585),(54,50461),(55,53472),(56,56621),(57,59917),(58,63366),(59,66971),(60,70741),(61,74682),(62,78800),(63,83104),(64,87600),(65,92294),(66,97198),(67,102318),(68,107663),(69,113242),(70,119064),(71,125138),(72,131476),(73,138087),(74,144983),(75,152173),(76,159672),(77,167489),(78,175639),(79,184137),(80,192995),(81,202225),(82,211845),(83,221870),(84,232315),(85,243198),(86,254537),(87,266350),(88,278655),(89,291473),(90,304822),(91,318726),(92,333206),(93,348286),(94,363990),(95,380342),(96,397366),(97,415092),(98,433547),(99,452761),(100,472764),(101,493586),(102,515260),(103,537822),(104,561305),(105,585748),(106,611190),(107,637670),(108,665227),(109,693909),(110,723758),(111,754819),(112,787143),(113,820781),(114,855784),(115,892206),(116,930107),(117,969544),(118,1010577),(119,1053272),(120,1097695),(121,1143915),(122,1192004),(123,1242037),(124,1294089),(125,1348244),(126,1404586),(127,1463202);
/*!40000 ALTER TABLE `levels` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `luck_use`
--

DROP TABLE IF EXISTS `luck_use`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `luck_use` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fkey_users_id` int(11) NOT NULL,
  `use_type` enum('action','energy','money','skill_reset') COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount_before` int(11) DEFAULT NULL COMMENT 'amount of "type" before action',
  `amount_filled` int(11) NOT NULL DEFAULT '0',
  `amount_now` int(11) DEFAULT NULL COMMENT 'amount of "type" after action',
  `luck_remaining` int(11) NOT NULL DEFAULT '0',
  `comment` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'explanation',
  PRIMARY KEY (`id`),
  KEY `fkey_users_id` (`fkey_users_id`),
  KEY `type` (`use_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `luck_use`
--

LOCK TABLES `luck_use` WRITE;
/*!40000 ALTER TABLE `luck_use` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `luck_use` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `message_blocks`
--

DROP TABLE IF EXISTS `message_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `message_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkey_blocking_users_id` int(11) NOT NULL,
  `fkey_blocked_users_id` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fkey_blocking_users_id` (`fkey_blocking_users_id`),
  KEY `fkey_blocked_users_id` (`fkey_blocked_users_id`),
  CONSTRAINT `message_blocks_ibfk_3` FOREIGN KEY (`fkey_blocking_users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `message_blocks_ibfk_4` FOREIGN KEY (`fkey_blocked_users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=292 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_blocks`
--

LOCK TABLES `message_blocks` WRITE;
/*!40000 ALTER TABLE `message_blocks` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `message_blocks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `neighborhood_buildings`
--

DROP TABLE IF EXISTS `neighborhood_buildings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `neighborhood_buildings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkey_neighborhoods_id` int(11) NOT NULL,
  `fkey_buildings_id` int(11) NOT NULL,
  `level` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fkey_neighborhoods_id` (`fkey_neighborhoods_id`),
  KEY `fkey_buildings_id` (`fkey_buildings_id`),
  CONSTRAINT `neighborhood_buildings_ibfk_1` FOREIGN KEY (`fkey_neighborhoods_id`) REFERENCES `neighborhoods` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `neighborhood_buildings_ibfk_2` FOREIGN KEY (`fkey_buildings_id`) REFERENCES `buildings` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `neighborhood_buildings`
--

LOCK TABLES `neighborhood_buildings` WRITE;
/*!40000 ALTER TABLE `neighborhood_buildings` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `neighborhood_buildings` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `neighborhood_messages`
--

DROP TABLE IF EXISTS `neighborhood_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `neighborhood_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fkey_users_from_id` int(11) NOT NULL,
  `fkey_users_to_id` int(11) NOT NULL DEFAULT '0',
  `fkey_neighborhoods_id` int(11) NOT NULL,
  `message` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fkey_users_from_id` (`fkey_users_from_id`),
  KEY `fkey_users_to_id` (`fkey_users_to_id`),
  KEY `fkey_neighborhoods_id` (`fkey_neighborhoods_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `neighborhood_messages`
--

LOCK TABLES `neighborhood_messages` WRITE;
/*!40000 ALTER TABLE `neighborhood_messages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `neighborhood_messages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `neighborhoods`
--

DROP TABLE IF EXISTS `neighborhoods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `neighborhoods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `xcoor` smallint(6) NOT NULL,
  `ycoor` smallint(6) NOT NULL,
  `lat` float NOT NULL DEFAULT '0',
  `long` float NOT NULL DEFAULT '0',
  `district` smallint(6) NOT NULL,
  `has_elections` tinyint(1) NOT NULL DEFAULT '0',
  `is_limited` tinyint(1) NOT NULL DEFAULT '0',
  `is_habitable` tinyint(1) NOT NULL DEFAULT '0',
  `rating` decimal(5,2) NOT NULL DEFAULT '60.00',
  `money_available` int(11) NOT NULL DEFAULT '0' COMMENT 'amount of money in that hood''s treasury, ready to use',
  `money_waiting` int(11) NOT NULL DEFAULT '0' COMMENT 'amount of money in that hood''s treasury, waiting to become available',
  `residents` int(11) NOT NULL DEFAULT '10',
  `welcome_msg` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `welcome_song` int(11) NOT NULL DEFAULT '0' COMMENT 'what song should be played when people enter the hood',
  `special_int` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `welcome_song` (`welcome_song`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `neighborhoods`
--

LOCK TABLES `neighborhoods` WRITE;
/*!40000 ALTER TABLE `neighborhoods` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `neighborhoods` VALUES (0,'Nowhere',0,0,0,0,0,0,0,0,50.00,0,0,4,NULL,0,5),(1,'Judea',40,260,0,0,0,1,0,0,50.00,0,0,4,'Welcome to Third&#039;s land',0,5),(2,'Jordan',120,200,0,0,0,1,0,0,50.00,0,0,4,'Beware of the dog!',0,4),(3,'Moab',110,280,0,0,0,1,0,0,50.00,0,0,4,':-P&quot;©',0,3),(4,'Edom',130,340,0,0,0,1,0,0,50.00,0,0,4,'Maybe someday a family other than DR will be able to hold a region more than a few hours',0,5),(5,'Aram',290,180,0,0,0,1,0,0,50.00,0,0,4,'Third was here, who cares?',0,5),(6,'Babylon',370,240,0,0,0,1,0,0,50.00,0,0,4,'    ',0,99),(7,'Shazer',190,430,0,0,0,1,0,0,50.00,0,0,4,'Just look up, and see the wonders I&#039;ve seen!',0,4),(8,'Bekkah',240,510,0,0,0,1,0,0,50.00,0,0,4,'Lehites are weak',0,5),(9,'Unaizah',320,410,0,0,0,1,0,0,50.00,0,0,4,'S.G. Stands for smelly gorillas... And lays down for chimps ',0,4),(10,'Hajr',410,520,0,0,0,1,0,0,50.00,0,0,4,'Saevin is a girl',0,4),(11,'Zagros',470,220,0,0,0,0,0,0,50.00,0,0,4,NULL,0,4),(12,'Khayappa',220,290,0,0,0,1,0,0,50.00,0,0,4,'Hi and bye!',0,5),(13,'Jizan',300,620,0,0,0,1,0,0,50.00,0,0,4,'Lehites smell like a dead donkey&#039;s butt...',0,3),(14,'Dhamar',370,740,0,0,0,1,0,0,50.00,0,0,4,'Third land',0,5);
/*!40000 ALTER TABLE `neighborhoods` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `purchases`
--

DROP TABLE IF EXISTS `purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fkey_users_id` int(11) NOT NULL,
  `amount_now` int(11) NOT NULL DEFAULT '0',
  `amount_purchased` int(11) NOT NULL DEFAULT '0',
  `purchase` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nonce` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fkey_users_id` (`fkey_users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchases`
--

LOCK TABLES `purchases` WRITE;
/*!40000 ALTER TABLE `purchases` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `purchases` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `quest_completion`
--

DROP TABLE IF EXISTS `quest_completion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quest_completion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkey_users_id` int(11) NOT NULL,
  `fkey_quests_id` int(11) NOT NULL,
  `percent_complete` int(11) NOT NULL,
  `bonus_given` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fkey_users_id_2` (`fkey_users_id`,`fkey_quests_id`),
  UNIQUE KEY `fkey_users_id_3` (`fkey_users_id`,`fkey_quests_id`),
  KEY `fkey_users_id` (`fkey_users_id`),
  KEY `fkey_quests_id` (`fkey_quests_id`),
  CONSTRAINT `quest_completion_ibfk_3` FOREIGN KEY (`fkey_users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `quest_completion_ibfk_4` FOREIGN KEY (`fkey_quests_id`) REFERENCES `quests` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quest_completion`
--

LOCK TABLES `quest_completion` WRITE;
/*!40000 ALTER TABLE `quest_completion` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `quest_completion` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `quest_group_bonus`
--

DROP TABLE IF EXISTS `quest_group_bonus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quest_group_bonus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkey_quest_groups_id` int(11) NOT NULL,
  `fkey_equipment_id` int(11) NOT NULL DEFAULT '0',
  `fkey_land_id` int(11) NOT NULL DEFAULT '0',
  `fkey_staff_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fkey_quest_groups_id` (`fkey_quest_groups_id`),
  KEY `fkey_equipment_id` (`fkey_equipment_id`),
  KEY `fkey_land_id` (`fkey_land_id`),
  KEY `fkey_staff_id` (`fkey_staff_id`),
  CONSTRAINT `quest_group_bonus_ibfk_1` FOREIGN KEY (`fkey_quest_groups_id`) REFERENCES `quest_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `quest_group_bonus_ibfk_2` FOREIGN KEY (`fkey_equipment_id`) REFERENCES `equipment` (`id`) ON DELETE CASCADE,
  CONSTRAINT `quest_group_bonus_ibfk_3` FOREIGN KEY (`fkey_land_id`) REFERENCES `land` (`id`) ON DELETE CASCADE,
  CONSTRAINT `quest_group_bonus_ibfk_4` FOREIGN KEY (`fkey_staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1002 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quest_group_bonus`
--

LOCK TABLES `quest_group_bonus` WRITE;
/*!40000 ALTER TABLE `quest_group_bonus` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `quest_group_bonus` VALUES (0,0,6,0,0),(1,1,29,0,0),(2,2,29,0,0),(3,3,36,0,0),(6,6,54,0,0),(7,7,39,0,0),(100,100,52,0,0),(1001,1001,49,0,0);
/*!40000 ALTER TABLE `quest_group_bonus` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `quest_group_completion`
--

DROP TABLE IF EXISTS `quest_group_completion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quest_group_completion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkey_users_id` int(11) NOT NULL,
  `fkey_quest_groups_id` int(11) NOT NULL,
  `times_completed` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fkey_users_id` (`fkey_users_id`),
  KEY `fkey_quest_groups_id` (`fkey_quest_groups_id`),
  CONSTRAINT `quest_group_completion_ibfk_3` FOREIGN KEY (`fkey_users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `quest_group_completion_ibfk_4` FOREIGN KEY (`fkey_quest_groups_id`) REFERENCES `quest_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quest_group_completion`
--

LOCK TABLES `quest_group_completion` WRITE;
/*!40000 ALTER TABLE `quest_group_completion` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `quest_group_completion` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `quest_groups`
--

DROP TABLE IF EXISTS `quest_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quest_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ready_for_bonus` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `highlight_in_hood` int(11) DEFAULT NULL COMMENT 'whether to show when you move to that hood',
  PRIMARY KEY (`id`),
  KEY `highlight_in_hood` (`highlight_in_hood`),
  CONSTRAINT `quest_groups_ibfk_1` FOREIGN KEY (`highlight_in_hood`) REFERENCES `neighborhoods` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1002 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quest_groups`
--

LOCK TABLES `quest_groups` WRITE;
/*!40000 ALTER TABLE `quest_groups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `quest_groups` VALUES (0,1,'Leaving Jerusalem','',NULL),(1,1,'The Valley of Lemuel','',NULL),(2,1,'Retrieving the Records, Pt. 1','',NULL),(3,1,'Retrieving the Records, Pt. 2','',NULL),(4,1,'Convincing Ishmael','',NULL),(5,1,'Returning to Lehi and Sariah','',NULL),(6,1,'Finding the Liahona','',NULL),(7,1,'Food and Faith, Pt. 1','',NULL),(8,1,'Food and Faith, Pt. 2','',NULL),(9,0,'Food and Faith, Pt. 3','',NULL),(100,1,'Learning to Trade','',NULL),(1001,1,'Love in the Desert','',NULL);
/*!40000 ALTER TABLE `quest_groups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `quests`
--

DROP TABLE IF EXISTS `quests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `group` int(11) NOT NULL DEFAULT '0',
  `name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(768) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkey_neighborhoods_id` int(11) NOT NULL,
  `required_level` int(11) NOT NULL DEFAULT '1',
  `required_energy` int(11) NOT NULL,
  `land_required_quantity` int(11) NOT NULL DEFAULT '0',
  `fkey_land_required_id` int(11) NOT NULL DEFAULT '0',
  `equipment_1_required_quantity` int(11) NOT NULL DEFAULT '0',
  `fkey_equipment_1_required_id` int(11) NOT NULL DEFAULT '0',
  `equipment_2_required_quantity` int(11) NOT NULL DEFAULT '0',
  `fkey_equipment_2_required_id` int(11) NOT NULL DEFAULT '0',
  `equipment_3_required_quantity` int(11) NOT NULL DEFAULT '0',
  `fkey_equipment_3_required_id` int(11) NOT NULL DEFAULT '0',
  `clan_equipment_1_required_quantity` int(11) NOT NULL DEFAULT '0',
  `fkey_clan_equipment_1_required_id` int(11) NOT NULL DEFAULT '0',
  `clan_equipment_1_consumed_quantity` int(11) NOT NULL DEFAULT '0',
  `fkey_clan_equipment_1_consumed_id` int(11) NOT NULL DEFAULT '0',
  `staff_required_quantity` int(11) NOT NULL DEFAULT '0',
  `fkey_staff_required_id` int(11) NOT NULL DEFAULT '0',
  `need_party` tinyint(1) NOT NULL DEFAULT '0',
  `need_clan` tinyint(1) NOT NULL DEFAULT '0',
  `need_job` tinyint(1) NOT NULL DEFAULT '0',
  `experience` int(11) NOT NULL,
  `min_money` int(11) NOT NULL,
  `max_money` int(11) NOT NULL,
  `percent_complete` int(11) NOT NULL DEFAULT '10',
  `chance_of_loot` int(11) NOT NULL DEFAULT '0',
  `fkey_loot_equipment_id` int(11) NOT NULL DEFAULT '0',
  `chance_of_loot_staff` int(11) NOT NULL DEFAULT '0',
  `fkey_loot_staff_id` int(11) NOT NULL DEFAULT '0',
  `fkey_enhanced_competencies_id` int(11) NOT NULL DEFAULT '0',
  `completion_sound` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `location` (`fkey_neighborhoods_id`),
  KEY `fkey_loot_equipment_id` (`fkey_loot_equipment_id`),
  KEY `fkey_loot_staff_id` (`fkey_loot_staff_id`),
  KEY `fkey_equipment_1_required_id` (`fkey_equipment_1_required_id`),
  KEY `fkey_equipment_2_required_id` (`fkey_equipment_2_required_id`),
  KEY `fkey_staff_required_id` (`fkey_staff_required_id`),
  KEY `fkey_land_required_id` (`fkey_land_required_id`),
  KEY `fkey_equipment_3_required_id` (`fkey_equipment_3_required_id`),
  KEY `fkey_clan_equipment_1_id` (`fkey_clan_equipment_1_required_id`),
  KEY `fkey_clan_1_consumed_id` (`fkey_clan_equipment_1_consumed_id`),
  KEY `fkey_clan_equipment_1_consumed_id` (`fkey_clan_equipment_1_consumed_id`),
  KEY `fkey_enhanced_competencies_id` (`fkey_enhanced_competencies_id`),
  CONSTRAINT `quests_ibfk_12` FOREIGN KEY (`fkey_neighborhoods_id`) REFERENCES `neighborhoods` (`id`),
  CONSTRAINT `quests_ibfk_13` FOREIGN KEY (`fkey_land_required_id`) REFERENCES `land` (`id`),
  CONSTRAINT `quests_ibfk_14` FOREIGN KEY (`fkey_equipment_1_required_id`) REFERENCES `equipment` (`id`),
  CONSTRAINT `quests_ibfk_15` FOREIGN KEY (`fkey_equipment_2_required_id`) REFERENCES `equipment` (`id`),
  CONSTRAINT `quests_ibfk_16` FOREIGN KEY (`fkey_staff_required_id`) REFERENCES `staff` (`id`),
  CONSTRAINT `quests_ibfk_17` FOREIGN KEY (`fkey_loot_equipment_id`) REFERENCES `equipment` (`id`),
  CONSTRAINT `quests_ibfk_18` FOREIGN KEY (`fkey_loot_staff_id`) REFERENCES `staff` (`id`),
  CONSTRAINT `quests_ibfk_19` FOREIGN KEY (`fkey_equipment_3_required_id`) REFERENCES `equipment` (`id`),
  CONSTRAINT `quests_ibfk_20` FOREIGN KEY (`fkey_clan_equipment_1_required_id`) REFERENCES `equipment` (`id`),
  CONSTRAINT `quests_ibfk_21` FOREIGN KEY (`fkey_clan_equipment_1_consumed_id`) REFERENCES `equipment` (`id`),
  CONSTRAINT `quests_ibfk_22` FOREIGN KEY (`fkey_enhanced_competencies_id`) REFERENCES `competencies` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quests`
--

LOCK TABLES `quests` WRITE;
/*!40000 ALTER TABLE `quests` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `quests` VALUES (1,1,0,'Your father prayed to God','for the people of his city.&nbsp; Listen to his story.<br/><br/><strong>1 Nephi 1:5</strong>: Wherefore it came to pass that my father, Lehi, as he went forth prayed unto the Lord, yea, even with all his heart, in behalf of his people.',0,1,10,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,3,5,52,0,0,0,0,0,'',''),(2,1,0,'Your father saw a vision','that told him that Jerusalem was about to be destroyed.<br/><br/><strong>1 Nephi 1:7-8</strong>: And it came to pass that he returned to his own house at Jerusalem; and he cast himself upon his bed ... He was carried away in a vision, even that he saw the heavens open, and he thought he saw God sitting upon his throne, surrounded with numberless concourses of angels ...',0,1,25,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,8,15,34,0,0,0,0,0,'',''),(3,1,0,'He told people what he saw','but they mocked him and did not listen.<br/><br/><strong>1 Nephi 1:18-9</strong>: ... He went forth among the people, and began to prophesy and to declare unto them concerning the things which he had both seen and heard.&nbsp; And it came to pass that the Jews did mock him because of the things which he testified of them ...',0,2,30,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,14,20,34,0,0,0,0,0,'',''),(4,1,0,'The people tried to kill him','and he was forced to run and hide.<br/><br/><strong>1 Nephi 1:20</strong>: ... They were angry with him; yea, even as with the prophets of old, whom they had cast out, and stoned, and slain; and they also sought his life, that they might take it away.',0,2,40,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,16,24,34,0,0,0,0,0,'',''),(5,1,0,'God warns Lehi to leave','and so you start packing your camels for a journey into the wilderness.<br/><br/><strong>1 Nephi 2:2</strong>: ... The Lord commanded my father, even in a dream, that he should take his family and depart into the wilderness.',0,3,40,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,18,24,26,0,0,0,0,0,'',''),(6,1,0,'Gather many bags of food','for the long journey ahead.<br/><br/><strong>1 Nephi 2:4</strong>: And he left his house ... and took nothing with him, save it were his family, and provisions, and tents ...',0,3,50,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,22,30,20,60,1,0,0,0,'',''),(7,1,0,'Gather up clothing','enough to last you a long time.<br/><br/><strong>1 Nephi 2:4</strong>: And he left his house ... and took nothing with him, save it were his family, and provisions, and tents ...',0,4,60,4,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,25,35,26,60,2,0,0,0,'',''),(8,1,0,'Gather up tents','so that you and your family will have a place to stay in the desert.<br/><br/><strong>1 Nephi 2:4</strong>: And he left his house ... and took nothing with him, save it were his family, and provisions, and tents ...',0,5,100,8,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,12,50,70,30,60,3,0,0,0,'',''),(9,1,0,'Leave Jerusalem','and head south into the wilderness.<br/><br/><strong>1 Nephi 2:4-5</strong>: ... [H]e departed into the wilderness … And he came down by the borders near the shore of the Red Sea ...',0,6,120,8,1,10,1,10,2,10,3,0,0,0,0,0,0,0,0,0,14,80,120,34,0,0,0,0,0,'',''),(10,1,1,'Travel south','for three days in the wilderness.<br/><br/><strong>1 Nephi 2:5-6:</strong>  ... He did travel ... three days in the wilderness.',4,7,80,10,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,50,80,34,0,0,0,0,0,'',''),(11,1,1,'Rest in a valley','and pitch your tents.<br/><br/><strong>1 Nephi 2:6:</strong> ... He pitched his tent in a valley by the side of a river of water.',4,8,90,0,0,12,3,0,0,0,0,0,0,0,0,0,0,0,0,0,12,60,90,34,0,0,0,0,0,'',''),(12,1,1,'Lehi created an altar','and thanked God for his blessings.<br/><br/><strong>1 Nephi 2:7:</strong> ... He built an altar of stones, and made an offering unto the Lord, and gave thanks unto the Lord our God.',4,9,75,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,50,70,30,0,0,0,0,0,'',''),(13,1,1,'Pray to know','whether what your father says is true or not.<br/><br/><strong>1 Nephi 2:16:</strong> ... I did cry unto the Lord; and behold he did visit me, and did soften my heart that I did believe all the words which had been spoken by my father ...',4,10,120,0,0,15,1,0,0,0,0,0,0,0,0,0,0,0,0,0,20,60,80,25,40,9,0,0,0,'',''),(14,1,1,'Talk to your older brother, Sam','about the answer to your prayer.&nbsp; He listens to you.<br/><br/><strong>1 Nephi 2:17:</strong> And I spake unto Sam, making known unto him the things which the Lord had manifested unto me ... [and] he believed in my words.',4,11,100,0,0,1,9,0,0,0,0,0,0,0,0,0,0,0,0,0,11,75,80,34,0,0,0,0,0,'',''),(15,1,1,'Talk to your oldest brothers, Laman and Lemuel','about the answer to your prayer.&nbsp; They will not listen to you.<br/><br/><strong>1 Nephi 2:17:</strong> But, behold, Laman and Lemuel would not hearken unto my words ...',4,12,110,0,0,2,9,0,0,0,0,0,0,0,0,0,0,0,0,0,12,90,120,26,0,0,0,0,0,'',''),(16,1,2,'Your father talks with you','and asks you to return with your brothers to Jerusalem to get the sacred records.<br/><br/><strong>1 Nephi 3:2-4:</strong> ... [H]e spake unto me, saying ... the Lord hath commanded me that thou and thy brethren shall return to Jerusalem. ... Laban hath the record of the Jews, ... engraven upon plates of brass. ... [T]hou and thy brothers should go unto the house of Laban, and seek the records.',4,14,100,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,12,40,60,34,0,0,0,0,0,'',''),(17,1,2,'Decide to be obedient','to your father and start loading your camels for your trip.<br/><br/><strong>1 Nephi 3:7:</strong> ... I, Nephi, said unto my father: I will go and do the things which the Lord hath commanded, for I know that the Lord giveth no commandments unto the children of men, save he shall prepare a way for them that they may accomplish the thing which he commandeth them.',4,15,120,4,1,3,9,0,0,0,0,0,0,0,0,0,0,0,0,0,20,60,80,20,0,0,0,0,0,'',''),(18,1,2,'Start your journey','with your brothers back to Jerusalem.<br/><br/><strong>1 Nephi 3:9:</strong> And I, Nephi, and my brethren took our journey in the wilderness, with our tents, to go up to the land of Jerusalem.',4,17,150,4,1,4,9,0,0,0,0,0,0,0,0,0,0,0,0,0,16,25,36,20,35,10,0,0,0,'',''),(19,1,2,'Cast lots','to see who will go get the plates.<br/><br/><strong>1 Nephi 3:10-11:</strong> ... [W]hen we had gone up to the land of Jerusalem, I and my brethren did consult one with another.&nbsp; And we cast lots &mdash; who of us should go in unto the house of Laban. ',1,18,70,0,0,1,10,0,0,0,0,0,0,0,0,0,0,0,0,0,8,14,20,17,0,0,0,0,0,'',''),(20,1,2,'Laman is chosen','to get the plates from Laban.&nbsp; He visits Laban and asks for the plates.<br/><br/><strong>1 Nephi 3:10-11:</strong> ...  [T]he lot fell upon Laman; and Laman went in unto the house of Laban, and he talked with him as he sat in his house.&nbsp; And he desired of Laban the records which were engraven upon the plates of brass.',1,20,110,0,0,1,10,0,0,0,0,0,0,0,0,0,0,0,0,0,18,30,44,34,0,0,0,0,0,'',''),(21,1,2,'Laban is angry','and sends his servants to kill Laman.<br/><br/><strong>1 Nephi 3:13:</strong> ...  Laban was angry, and thrust him out from his presence ... Wherefore, he said unto him: Behold thou art a robber, and I will slay thee.',1,21,140,0,0,1,10,0,0,0,0,0,0,0,0,0,0,0,0,0,22,40,55,25,0,0,0,0,0,'',''),(22,1,2,'Your brothers want to quit','but you convince them to try again.&nbsp; You go to your old house and get your gold and jewels to buy the plates.<br/><br/><strong>1 Nephi 3:21-22:</strong>  I persuade[d] my brethren, that they might be faithful in keeping the commandments of God.&nbsp; ... [W]e went down to the land of our inheritance, and we did gather together our gold, and our silver, and our precious things.',1,22,130,0,0,1,10,0,0,0,0,0,0,0,0,0,0,0,0,0,12,75,100,26,34,13,0,0,0,'',''),(23,1,2,'All of you go','visit Laban to see if you can purchase the plates from him.<br/><br/><strong>1 Nephi 3:24:</strong> [W]e went in unto Laban, and desired him that he would give unto us the records which were engraven upon the plates of brass, for which we would give unto him our gold, and our silver, and all our precious things.',1,24,160,0,0,1,10,4,13,0,0,0,0,0,0,0,0,0,0,0,26,48,60,34,0,0,0,0,0,'',''),(24,1,2,'Laban takes your property','and uses his servants to chase all of you away.<br/><br/><strong>1 Nephi 3:25-26:</strong> ... [W]hen Laban saw our property ... he thrust us out, and sent his servants to slay us, that he might obtain our property.&nbsp; And ... we did flee before the servants of Laban, and we were obliged to leave behind our property, and it fell into the hands of Laban.',1,25,180,0,0,1,10,4,13,0,0,0,0,0,0,0,0,0,0,0,36,30,50,26,0,0,0,0,0,'',''),(25,1,2,'You flee and hide','in a cave.&nbsp; Laman and Lemuel are angry and beat you and Sam with sticks.<br/><br/><strong>1 Nephi 3:25-26:</strong> ... [W]e fled into the wilderness ... and we hid ourselves in the cavity of a rock.&nbsp; ... Laman was angry with me ... and also was Lemuel ... Laman and Lemuel did speak many hard words unto us, their younger brothers, and they did smite us even with a rod.',1,26,200,0,0,1,10,0,0,0,0,0,0,0,0,0,0,0,0,0,38,32,52,25,0,0,0,0,0,'',''),(26,1,3,'An Angel comes','and commands your brothers to stop.<br/><br/><strong>1 Nephi 3:29:</strong> ... [A]s they smote us … an angel of the Lord came and stood before them … saying: Why do ye smite your younger brother with a rod? Know ye not that the Lord hath chosen him to be a ruler over you, and this because of your iniquities? … [G]o up to Jerusalem again, and the Lord will deliver Laban into your hands.',1,23,140,0,0,1,10,0,0,0,0,0,0,0,0,0,0,0,0,0,32,24,40,25,0,0,0,0,0,'',''),(27,1,3,'You sneak back into the city','by night.<br/><br/><strong>1 Nephi 4:4-5:</strong> ... [T]hey were yet wroth, and did still continue to murmur; nevertheless they did follow me up until we came without the walls of Jerusalem.&nbsp; And it was by night; and I caused that they should hide themselves without the walls.',1,25,160,0,0,1,10,0,0,0,0,0,0,0,0,0,0,0,0,0,36,30,45,34,0,0,0,0,0,'',''),(28,1,3,'As you near Laban\'s house','you see Laban fallen to the ground, drunk.<br/><br/><strong>1 Nephi 4:6-8:</strong> I was led by the Spirit, not knowing beforehand the things which I should do.&nbsp; Nevertheless I went forth, and as I came near unto the house of Laban I beheld a man, and he had fallen to the earth before me, for he was drunken with wine.&nbsp; And when I came to him I found that it was Laban.',1,26,120,0,0,1,10,0,0,0,0,0,0,0,0,0,0,0,0,0,20,22,36,34,10,14,0,0,0,'',''),(29,1,3,'The Spirit commands you','to kill Laban with his own sword.<br/><br/><strong>1 Nephi 4:10, 12, 18:</strong> … I was constrained by the Spirit that I should kill Laban; but I said in my heart: Never at any time have I shed the blood of man … [T]he Spirit said unto me again: Slay him, for the Lord hath delivered him into thy hands … Therefore I did obey the voice of the Spirit … and I smote off his head with his own sword.',1,27,180,0,0,1,10,1,14,0,0,0,0,0,0,0,0,0,0,0,32,24,48,25,10,15,0,0,0,'',''),(30,1,3,'You dress up as Laban','so that you can pretend to be him.<br/><br/><strong>1 Nephi 4:19:</strong> And after I had smitten off his head with his own sword, I took the garments of Laban and put them upon mine own body; yea, even every whit; and I did gird on his armor about my loins.',1,29,200,0,0,1,10,1,14,1,15,0,0,0,0,0,0,0,0,0,32,28,44,25,0,0,0,0,0,'',''),(31,1,3,'You go to Laban\'s treasury','and command his servant to bring the plates to you and your brothers.<br/><br/><strong>1 Nephi 4:20-4:</strong> … I went forth towards the treasury of Laban … and … saw the servant of Laban … And I commanded him in the voice of Laban … that I should carry the engravings, which were upon the plates of brass, to my elder brethren, who were without the walls.',1,30,240,0,0,1,10,1,14,1,15,0,0,0,0,0,0,0,0,0,36,32,48,26,10,17,0,0,0,'',''),(32,1,3,'Your brothers flee from you','thinking that you are Laban, come to kill them.<br/><br/><strong>1 Nephi 4:28:</strong> … [W]hen Laman saw me he was exceedingly frightened, and also Lemuel and Sam. And they fled from before my presence; for they supposed it was Laban, and that he had slain me and had sought to take away their lives also.',1,31,250,0,0,1,10,1,15,1,17,0,0,0,0,0,0,0,0,0,38,40,56,40,0,0,0,0,0,'',''),(33,1,3,'Taking off your disguise','you call your brothers back.&nbsp; The servant, realizing you are not Laban, starts to run away.<br/><br/><strong>1 Nephi 4:29-30:</strong> … I called after them, and they did hear me; wherefore they did cease to flee from my presence ... when the servant of Laban beheld my brethren he began to tremble, and was about to flee from before me and return to the city of Jerusalem.',1,32,260,0,0,1,10,1,15,1,17,0,0,0,0,0,0,0,0,0,40,45,60,40,0,0,0,0,0,'',''),(34,1,3,'Grab Zoram','so he won\'t run away!<br/><br/><strong>1 Nephi 4:31-35:</strong> I did seize upon the servant of Laban … [and] I spake with him … if he would hearken unto our words, we would spare his life. … [And] Zoram did take courage at the words which I spake … and he also made an oath unto us that he would tarry with us from that time forth.',1,33,280,0,0,1,10,1,15,1,17,0,0,0,0,0,0,0,0,0,42,48,65,34,0,0,0,0,0,'',''),(35,1,3,'Return to your family','having successfully completed your quest.<br/><br/><strong>1 Nephi 4:38:</strong> And it came to pass that we took the plates of brass and the servant of Laban, and departed into the wilderness, and journeyed unto the tent of our father.',1,34,200,0,0,1,10,1,15,1,17,0,0,0,0,0,0,0,0,0,30,40,50,25,33,18,0,0,0,'',''),(36,1,4,'Lehi and Sariah welcome you back','and your new friend, Zoram.<br/><br/><strong>1 Nephi 5:1:</strong> And it came to pass that after we had come down into the wilderness unto our father, behold, he was filled with joy, and also my mother, Sariah, was exceedingly glad, for she truly had mourned because of us.',4,31,240,0,0,1,17,1,18,0,0,0,0,0,0,0,0,0,0,0,40,50,75,25,0,0,0,0,0,'',''),(37,1,4,'Lehi thanks God','for the deliverance of his sons, and starts to read the records.<br/><br/><strong>1 Nephi 5:10:</strong> And after they had given thanks unto the God of Israel, my father, Lehi, took the records which were engraven upon the plates of brass, and he did search them from the beginning.',4,32,260,0,0,1,17,0,0,0,0,0,0,0,0,0,0,0,0,0,42,60,80,33,0,0,0,0,0,'',''),(38,1,4,'Lehi prophesies',' concerning the plates and his seed.<br/><br/><strong>1 Nephi 5:17-19:</strong> [M]y father ...   was filled with the Spirit, and began to prophesy concerning his seed ... that these plates of brass should never perish; neither should they be dimmed any more by time.&nbsp;  And he prophesied many things concerning his seed.',4,33,280,0,0,1,17,0,0,0,0,0,0,0,0,0,0,0,0,0,45,64,88,26,0,0,0,0,0,'',''),(39,1,4,'Lehi agains asks','you and your brethren to go to Jerusalem, this time to convince Ishmael to join you.<br/><br/><strong>1 Nephi 7:1-2:</strong>\n... [T]he Lord spake unto him again, saying ... that he should [not] take his family into the wilderness alone ... \nI, Nephi, and my brethren, should again return unto the land of Jerusalem, and bring down Ishmael and his family into the wilderness.',4,34,300,0,0,1,18,0,0,0,0,0,0,0,0,0,0,0,0,0,48,66,92,26,0,0,0,0,0,'',''),(40,1,4,'Decide to be obedient again','and pack your camels for your journey back to Jerusalem.',4,35,340,4,1,1,18,0,0,0,0,0,0,0,0,0,0,0,0,0,50,70,90,40,20,24,0,0,0,'',''),(41,1,4,'Start your journey again','with your brothers, back to Jerusalem.<br/><br/><strong>1 Nephi 7:3:</strong> And it came to pass that I, Nephi, did again, with my brethren, go forth into the wilderness to go up to Jerusalem.',4,36,360,4,1,1,24,0,0,0,0,0,0,0,0,0,0,0,0,0,55,72,96,26,0,24,0,0,0,'',''),(42,1,4,'Gain Ishmael\'s trust','to convince him to journey with you to the wilderness.<br/><br/><strong>1 Nephi 7:4:</strong> And it came to pass that we went up unto the house of Ishmael, and we did gain favor in the sight of Ishmael, insomuch that we did speak unto him the words of the Lord.',1,37,400,0,0,1,24,0,0,0,0,0,0,0,0,0,0,0,0,0,62,76,102,34,0,0,0,0,0,'',''),(43,1,4,'Convince Ishmael\'s family','so they will come too!<br/><br/><strong>1 Nephi 7:5:</strong> And it came to pass that the Lord did soften the heart of Ishmael, and also his household...',1,38,420,0,0,1,24,0,0,0,0,0,0,0,0,0,0,0,0,0,70,78,104,20,20,25,0,0,0,'',''),(44,1,5,'Gather more bags of food','for the long journey back with Ishmael\'s family.',1,35,370,0,0,1,25,0,0,0,0,0,0,0,0,0,0,0,0,0,74,80,120,17,80,1,0,0,0,'',''),(45,1,5,'Gather more clothing','enough to last Ishmael\'s family a long time.',1,36,380,0,0,1,25,30,1,0,0,0,0,0,0,0,0,0,0,0,77,85,125,17,80,2,0,0,0,'',''),(46,1,5,'Gather more tents','so that Ishmael\'s family will have a place to stay in the desert.',1,37,400,0,0,1,25,30,2,0,0,0,0,0,0,0,0,0,0,0,80,90,135,17,80,3,0,0,0,'',''),(47,1,5,'Start your journey back','with Ishmael\'s family, to the rest of your family.<br/><br/><strong>1 Nephi 7:5:</strong> ... [T]hey took their journey with us down into the wilderness to the tent of our father.',1,38,420,0,0,1,25,30,3,0,0,0,0,0,0,0,0,0,0,0,85,95,140,26,0,0,0,0,0,'',''),(48,1,5,'Laman and Lemuel complain','As do some of family of Ishmael.<br/><br/><strong>1 Nephi 7:6:</strong> ... Laman and Lemuel, and two of the daughters of Ishmael, and the two sons of Ishmael and their families, did rebel against us; yea, against me, Nephi, and Sam, and their father, Ishmael, and his wife, and his three other daughters.',3,39,430,0,0,1,25,0,0,0,0,0,0,0,0,0,0,0,0,0,88,100,150,20,0,0,0,0,0,'',''),(49,1,5,'You speak to the people','exhorting them to be righteous.<br/><br/><strong>1 Nephi 7:8:</strong> I spake unto them, saying ... Behold ye are mine elder brethren, and how is it that ye are so hard in your hearts, and so blind in your minds, that ye have need that I, your younger brother, should speak unto you, yea, and set an example for you?',3,40,440,0,0,1,25,0,0,0,0,0,0,0,0,0,0,0,0,0,90,105,160,25,0,0,0,0,0,'',''),(50,1,5,'Angry with you','they decide to tie you up and leave you to die.<br/><br/><strong>1 Nephi 7:16:</strong> ... [T]hey did lay their hands upon me, for behold, they were exceedingly wroth, and they did bind me with cords ... that they might leave me in the wilderness to be devoured by wild beasts.',3,41,450,0,0,1,25,0,0,0,0,0,0,0,0,0,0,0,0,0,92,108,164,26,0,0,0,0,0,'',''),(51,1,5,'You pray to God','to get Him to help you escape.<br/><br/><strong>1 Nephi 7:17:</strong> I prayed unto the Lord, saying: O Lord, according to my faith which is in thee, wilt thou deliver me from the hands of my brethren; yea, even give me strength that I may burst these bands.',3,42,460,0,0,1,25,0,0,0,0,0,0,0,0,0,0,0,0,0,95,110,165,20,0,0,0,0,0,'',''),(52,1,5,'God answers your prayer','and helps you escape.<br/><br/><strong>1 Nephi 7:18:</strong> ... [W]hen I had said these words, behold, the bands were loosed from off my hands and feet.',3,43,470,0,0,1,25,0,0,0,0,0,0,0,0,0,0,0,0,0,96,112,170,20,0,0,0,0,0,'',''),(53,1,5,'You stand up','and speak to them again.<br/><br/><strong>1 Nephi 7:18, 20:</strong> I stood before my brethren, and I spake unto them again.&nbsp; And it came to pass that they were sorrowful, because of their wickedness, insomuch that they did bow down before me, and did plead with me that I would forgive them.',3,44,480,0,0,1,25,0,0,0,0,0,0,0,0,0,0,0,0,0,98,120,180,25,0,0,0,0,0,'',''),(54,1,5,'You return to your family','who are very happy to see you!<br/><br/><strong>1 Nephi 7:22:</strong> ... [W]e did come down unto the tent of our father.&nbsp; And after I and my brethren and all the house of Ishmael had come down unto the tent of my father, they did give thanks unto the Lord their God; and they did offer sacrifice and burnt offerings unto him.',4,45,450,0,0,1,25,0,0,0,0,0,0,0,0,0,0,0,0,0,100,125,175,17,20,28,0,0,0,'',''),(55,1,6,'You gather seeds','of every kind, in preparation for travel further into the wilderness.<br/><br/><strong>1 Nephi 8:1:</strong> And it came to pass that we had gathered together all manner of seeds of every kind, both of grain of every kind, and also of the seeds of fruit of every kind.',4,38,380,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,88,100,150,17,40,30,0,0,0,'',''),(56,1,6,'Your father has a vision','which causes him to fear for Laman and Lemuel.<br/><br/><strong>1 Nephi 8:36:</strong> ... [B]ecause of these things which he saw in a vision, he exceedingly feared for Laman and Lemuel; yea he feared lest they should be cast off from the presence of the Lord.',4,39,400,0,0,3,30,0,0,0,0,0,0,0,0,0,0,0,0,0,92,110,160,26,0,0,0,0,0,'',''),(57,1,6,'You marry','one of Ishmael\'s daughters.<br/><br/><strong>1 Nephi 16:7:</strong>And it came to pass that I, Nephi, took one of the daughters of Ishmael to wife ...',4,40,500,0,0,12,31,6,30,0,0,0,0,0,0,0,0,0,0,0,120,150,200,17,0,0,0,0,0,'',''),(58,1,6,'Your brothers and Zoram marry','Ishmael\'s other daughters.<br/><br/><strong>1 Nephi 16:7:</strong> ... [A]nd also, my brethren took of the daughters of Ishmael to wife; and also Zoram took the eldest daughter of Ishmael to wife.',4,41,440,0,0,4,31,9,30,0,0,0,0,0,0,0,0,0,0,0,110,140,180,26,0,0,0,0,0,'',''),(59,1,6,'The Lord commands Lehi to leave','tomorrow to go farther into the wilderness.<br/><br/><strong>1 Nephi 16:9:</strong> And it came to pass that the voice of the Lord spake unto my father by night, and commanded him that on the morrow he should take his journey into the wilderness.',4,42,470,0,0,12,30,0,0,0,0,0,0,0,0,0,0,0,0,0,120,150,190,20,0,0,0,0,0,'',''),(60,1,6,'Lehi discovers a ball','of curious workmanship: the Liahona.<br/><br/><strong>1 Nephi 16:10:</strong> And it came to pass that as my father arose in the morning, and went forth to the tent door, to his great astonishment he beheld upon the ground a round ball of curious workmanship; and it was of fine brass.',4,43,480,0,0,15,30,0,0,0,0,0,0,0,0,0,0,0,0,0,130,160,200,16,10,32,0,0,0,'',''),(61,1,6,'The Liahona directs you','which way you should journey.<br/><br/><strong>1 Nephi 16:10:</strong> And within the ball were two spindles; and the one pointed the way whither we should go into the wilderness.',4,44,500,0,0,1,32,18,30,0,0,0,0,0,0,0,0,0,0,0,140,170,210,25,0,0,0,0,0,'',''),(62,1,6,'Prepare to leave','so that you can travel into the wilderness.<br/><br/><strong>1 Nephi 16:11:</strong> And it came to pass that we did gather together whatsoever things we should carry into the wilderness, and all the remainder of our provisions which the Lord had given unto us; and we did take seed of every kind that we might carry into the wilderness.',4,45,510,0,0,1,32,21,30,0,0,0,0,0,0,0,0,0,0,0,150,160,200,25,10,30,0,0,0,'',''),(63,1,6,'Leave with your provisions','and head for the horizon.<br/><br/><strong>1 Nephi 16:12:</strong> And it came to pass that we did take our tents and depart into the wilderness, across the river Laman.',4,46,520,0,0,1,32,24,30,0,0,0,0,0,0,0,0,0,0,0,160,180,240,25,0,0,0,0,0,'',''),(64,1,7,'Travel again','according to the commandments of the Lord.<br/><br/><strong>1 Nephi 16:13:</strong> ... [W]e traveled for the space of four days, nearly a south-southeast direction, and we did pitch our tents again; and we did call the name of the place Shazer.',7,47,510,0,0,1,32,24,30,0,0,0,0,0,0,0,0,0,0,0,150,160,200,25,0,0,0,0,0,'',''),(65,1,7,'And again','because you are not there yet.<br/><br/><strong>1 Nephi 16:16-17:</strong> And we did follow the directions of the ball, which led us in the more fertile parts of the wilderness.&nbsp; And after we had traveled for the space of many days, we did pitch our tents for the space of a time, that we might again rest ourselves and obtain food for our families.',8,48,520,0,0,1,32,0,0,0,0,0,0,0,0,0,0,0,0,0,160,200,240,25,0,0,0,0,0,'',''),(66,1,7,'Go hunting','to find food for your family.<br/><br/><strong>1 Nephi 16:18:</strong> ... I, Nephi, went forth to slay food ...',8,49,560,0,0,1,37,0,0,0,0,0,0,0,0,0,0,0,0,0,180,240,280,20,10,38,0,0,0,'',''),(67,1,7,'Your bow breaks','as you hunt for food.<br/><br/><strong>1 Nephi 16:18:</strong> ... behold, I did break my bow, which was made of fine steel ...',8,50,540,0,0,1,37,0,0,0,0,0,0,0,0,0,0,0,0,0,170,220,260,34,0,0,0,0,0,'',''),(68,1,7,'Your family gets angry','because of their hunger.<br/><br/><strong>1 Nephi 16:20:</strong> And it came to pass that Laman and Lemuel and the sons of Ishmael did begin to murmur exceedingly, because of their sufferings and afflictions in the wilderness; and also my father began to murmur against the Lord his God; yea, and they were all exceedingly sorrowful, even that they did murmur against the Lord.',8,51,550,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,170,230,270,25,0,0,0,0,0,'',''),(69,1,7,'You chastise your family','for their lack of faith.<br/><br/><strong>1 Nephi 16:22:</strong> And it came to pass that I, Nephi, did speak much unto my brethren, because they had hardened their hearts again, even unto complaining against the Lord their God.',8,52,560,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,180,240,300,25,0,0,0,0,0,'',''),(70,1,8,'You make a bow','so that you can get more food for your family.<br/><br/><strong>1 Nephi 16:23:</strong> And it came to pass that I, Nephi, did make out of wood a bow, and out of a straight stick, an arrow; wherefore, I did arm myself with a bow and an arrow, with a sling and with stones.',8,51,600,0,0,6,16,1,40,0,0,0,0,0,0,0,0,0,0,0,200,250,300,20,20,41,0,0,0,'',''),(71,1,8,'And ask your father','where to go to find food.<br/><br/><strong>1 Nephi 16:23:</strong> And I said unto my father: Whither shall I go to obtain food?',8,52,580,0,0,6,16,1,40,1,41,0,0,0,0,0,0,0,0,0,210,260,300,25,20,44,0,0,0,'',''),(72,1,8,'Your father asks the Lord','and is chastened because of his murmuring.<br/><br/><strong>1 Nephi 16:24-5:</strong> And it came to pass that he did inquire of the Lord ... and he was truly chastened because of his murmuring against the Lord, insomuch that he was brought down into the depths of sorrow.',8,53,600,0,0,1,41,1,44,0,0,0,0,0,0,0,0,0,0,0,240,270,310,34,20,45,0,0,0,'',''),(73,1,8,'The Lord tells your father','to look at the Liahona.<br/><br/><strong>1 Nephi 16:26-7:</strong> ... [T]he voice of the Lord said unto him: Look upon the ball, and behold the things which are written.&nbsp; ... [W]hen my father beheld the things which were written upon the ball, he did fear and tremble exceedingly, and also my brethren and the sons of Ishmael and our wives.',8,54,620,0,0,1,32,1,45,0,0,0,0,0,0,0,0,0,0,0,280,350,400,20,20,46,0,0,0,'',''),(74,1,8,'Inspecting the Liahona','you learn that it works by faith.<br/><br/><strong>1 Nephi 16:28-9:</strong> ... I, Nephi, beheld the pointers which were in the ball, that they did work according to the faith and diligence and heed which we did give unto them.&nbsp; And there was also written upon them a new writing, which was plain to be read, which did give us understanding concerning the ways of the Lord ... And thus we see that by small means the Lord can bring about great things.',8,55,630,0,0,1,32,1,46,0,0,0,0,0,0,0,0,0,0,0,300,300,350,25,0,0,0,0,0,'',''),(75,1,1001,'You are betrothed','to a wonderful daughter of Ishmael, but how can you gain her favor?&nbsp; Ponder what you will need to do.',4,45,400,0,0,1,25,0,0,0,0,0,0,0,0,0,0,0,0,0,100,125,175,17,0,0,0,0,0,'',''),(76,1,1001,'Feeling uninspired','you decide to ask someone who knows more about women than you do &mdash; your mother, Sariah.&nbsp; What will she tell you?',4,46,420,0,0,1,25,0,0,0,0,0,0,0,0,0,0,0,0,0,110,140,190,17,20,47,0,0,0,'',''),(77,1,1001,'Sariah gives you','wise words.&nbsp; &quot;Son,&quot; she tells you, &quot;you will earn the favor of your bride and her respect by showing her that she is more important to you than anyone else in the world.&nbsp; Give her something that shows her this.&quot;',4,47,440,0,0,2,47,0,0,0,0,0,0,0,0,0,0,0,0,0,120,150,200,20,30,47,0,0,0,'',''),(78,1,1001,'You ponder again','what you could give your future bride.&nbsp; What would show her that she is more important to you than anything else?',4,48,460,0,0,6,47,0,0,0,0,0,0,0,0,0,0,0,0,0,130,165,220,15,40,47,0,0,0,'',''),(79,1,1001,'You ask your older brother Sam','if he is wondering the same thing you are.&nbsp; Maybe he has some ideas?',4,49,480,0,0,15,47,0,0,0,0,0,0,0,0,0,0,0,0,0,140,175,235,15,45,47,0,0,0,'',''),(80,1,1001,'Sam responds','with an idea for you.&nbsp; &quot;You\'ve always been good at building things, Nephi,&quot; he says, &quot;so why don\'t you make something for her?&nbsp; Something unique.&nbsp; Something she will treasure forever.&quot;',4,50,500,0,0,30,47,0,0,0,0,0,0,0,0,0,0,0,0,0,150,185,245,20,55,47,0,0,0,'',''),(81,1,1001,'You now have','the perfect idea!&nbsp; You thank Sam and plan your creation.&nbsp; Where will you find everything you need in the desert?',4,51,520,0,0,50,47,0,0,0,0,0,0,0,0,0,0,0,0,0,160,200,260,15,65,47,0,0,0,'',''),(82,1,1001,'You craft','the perfect gift for your betrothed.&nbsp; She loves it!',4,52,750,0,0,120,47,0,0,0,0,0,0,0,0,0,0,0,0,0,160,200,260,10,75,48,0,0,0,'',''),(83,1,100,'Rise up early','in the morning.&nbsp; As a merchant, you must learn to get up early each day, but today is a special day &mdash; today your tribe will deem you worthy of your own tradepost.',14,7,80,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,50,80,25,0,0,0,0,0,'',''),(84,1,100,'Eat some breakfast','since you have a long day ahead of you.&nbsp; Save some food for later.',14,8,100,0,0,3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,12,60,80,20,0,0,0,0,0,'',''),(85,1,100,'Decide your first item','to trade.&nbsp; What is there that you can obtain without too much effort that has value in the desert?&nbsp You decide on lizards &mdash; you can sell the meat for food and the skins for small bags or decorations.',14,9,110,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,15,70,100,17,0,0,0,0,0,'',''),(86,1,100,'Acquire the tools','to skin the lizards.&nbsp; You have very little with which to bargain, but it is enough to obtain a stone knife.',14,10,120,0,0,1,4,0,0,0,0,0,0,0,0,0,0,0,0,0,18,80,100,20,0,0,0,0,0,'',''),(87,1,100,'Catch a lizard','which is not as easy as you might think.',14,11,150,1,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,25,90,120,14,0,0,0,0,0,'',''),(88,1,100,'Use your knife','to skin it, being careful not to ruin either the skin or the meat.',14,12,160,1,3,1,4,0,0,0,0,0,0,0,0,0,0,0,0,0,28,100,120,14,75,50,0,0,0,'',''),(89,1,100,'Once you have enough skins','to trade, trade them for an item of value.',14,13,180,0,0,8,50,0,0,0,0,0,0,0,0,0,0,0,0,0,30,100,130,20,60,51,0,0,0,'','');
/*!40000 ALTER TABLE `quests` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `songs`
--

DROP TABLE IF EXISTS `songs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `songs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'available for use?',
  `display_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'name as shown to the player',
  `filename` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'name on file system',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'timestamp when created',
  `use_count` int(11) NOT NULL DEFAULT '0' COMMENT 'how many times selected for use',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `songs`
--

LOCK TABLES `songs` WRITE;
/*!40000 ALTER TABLE `songs` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `songs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkey_neighborhoods_id` int(11) NOT NULL,
  `fkey_values_id` int(11) NOT NULL,
  `required_level` int(11) NOT NULL,
  `is_loot` tinyint(1) NOT NULL DEFAULT '0',
  `quantity_limit` int(11) NOT NULL DEFAULT '0',
  `can_sell` tinyint(1) NOT NULL DEFAULT '1',
  `staff_or_agent` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 's',
  `price` int(11) NOT NULL,
  `price_increase` int(11) NOT NULL,
  `income` int(11) NOT NULL DEFAULT '0',
  `upkeep` int(11) NOT NULL DEFAULT '0',
  `initiative_bonus` int(11) NOT NULL,
  `endurance_bonus` int(11) NOT NULL,
  `elocution_bonus` int(11) NOT NULL DEFAULT '0',
  `energy_increase` int(11) NOT NULL DEFAULT '0',
  `extra_votes` int(11) NOT NULL DEFAULT '0',
  `extra_defending_votes` int(11) NOT NULL DEFAULT '0',
  `chance_of_loss` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fkey_neighborhoods_id` (`fkey_neighborhoods_id`),
  KEY `fkey_values_id` (`fkey_values_id`),
  CONSTRAINT `staff_ibfk_1` FOREIGN KEY (`fkey_neighborhoods_id`) REFERENCES `neighborhoods` (`id`),
  CONSTRAINT `staff_ibfk_2` FOREIGN KEY (`fkey_values_id`) REFERENCES `values` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff`
--

LOCK TABLES `staff` WRITE;
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `staff` VALUES (0,0,'No One','No One',0,0,0,0,0,0,'s',0,0,0,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `staff_failure_reasons`
--

DROP TABLE IF EXISTS `staff_failure_reasons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff_failure_reasons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkey_staff_id` int(11) NOT NULL,
  `message` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fkey_staff_id` (`fkey_staff_id`),
  CONSTRAINT `staff_failure_reasons_ibfk_1` FOREIGN KEY (`fkey_staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_failure_reasons`
--

LOCK TABLES `staff_failure_reasons` WRITE;
/*!40000 ALTER TABLE `staff_failure_reasons` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `staff_failure_reasons` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `staff_ownership`
--

DROP TABLE IF EXISTS `staff_ownership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff_ownership` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkey_staff_id` int(11) NOT NULL,
  `fkey_users_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fkey_staff_id_2` (`fkey_staff_id`,`fkey_users_id`),
  KEY `fkey_staff_id` (`fkey_staff_id`),
  KEY `fkey_users_id` (`fkey_users_id`),
  CONSTRAINT `staff_ownership_ibfk_3` FOREIGN KEY (`fkey_staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE,
  CONSTRAINT `staff_ownership_ibfk_4` FOREIGN KEY (`fkey_users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_ownership`
--

LOCK TABLES `staff_ownership` WRITE;
/*!40000 ALTER TABLE `staff_ownership` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `staff_ownership` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `system_messages`
--

DROP TABLE IF EXISTS `system_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `subtype` enum('mayor','system') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'system',
  `fkey_users_from_id` int(11) NOT NULL DEFAULT '0',
  `fkey_users_to_id` int(11) NOT NULL DEFAULT '0',
  `fkey_neighborhoods_id` int(11) NOT NULL DEFAULT '0',
  `message` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fkey_neighborhoods_id` (`fkey_neighborhoods_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_messages`
--

LOCK TABLES `system_messages` WRITE;
/*!40000 ALTER TABLE `system_messages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `system_messages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `user_attributes`
--

DROP TABLE IF EXISTS `user_attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_attributes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fkey_users_id` int(11) NOT NULL,
  `key` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fkey_users_id_2` (`fkey_users_id`,`key`),
  KEY `fkey_users_id` (`fkey_users_id`),
  CONSTRAINT `user_attributes_ibfk_1` FOREIGN KEY (`fkey_users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_attributes`
--

LOCK TABLES `user_attributes` WRITE;
/*!40000 ALTER TABLE `user_attributes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `user_attributes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `user_blocks`
--

DROP TABLE IF EXISTS `user_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `phone_id` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `phone_id` (`phone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_blocks`
--

LOCK TABLES `user_blocks` WRITE;
/*!40000 ALTER TABLE `user_blocks` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `user_blocks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `user_competencies`
--

DROP TABLE IF EXISTS `user_competencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_competencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkey_users_id` int(11) NOT NULL,
  `fkey_competencies_id` int(11) NOT NULL,
  `use_count` int(11) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fkey_users_id_2` (`fkey_users_id`,`fkey_competencies_id`),
  KEY `fkey_users_id` (`fkey_users_id`),
  KEY `fkey_competencies_id` (`fkey_competencies_id`),
  CONSTRAINT `user_competencies_ibfk_1` FOREIGN KEY (`fkey_users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_competencies_ibfk_2` FOREIGN KEY (`fkey_competencies_id`) REFERENCES `competencies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_competencies`
--

LOCK TABLES `user_competencies` WRITE;
/*!40000 ALTER TABLE `user_competencies` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `user_competencies` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `user_creations`
--

DROP TABLE IF EXISTS `user_creations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_creations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` datetime NOT NULL,
  `phone_id` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remote_ip` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `referred_by` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `referred_by` (`referred_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_creations`
--

LOCK TABLES `user_creations` WRITE;
/*!40000 ALTER TABLE `user_creations` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `user_creations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `user_messages`
--

DROP TABLE IF EXISTS `user_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `subtype` enum('comp','png','user') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `fkey_users_from_id` int(11) NOT NULL,
  `fkey_users_to_id` int(11) NOT NULL,
  `fkey_neighborhoods_id` int(11) NOT NULL DEFAULT '0',
  `private` tinyint(1) NOT NULL DEFAULT '0',
  `message` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fkey_users_to_id` (`fkey_users_to_id`),
  KEY `fkey_users_from_id` (`fkey_users_from_id`),
  KEY `fkey_neighborhoods_id` (`fkey_neighborhoods_id`),
  CONSTRAINT `user_messages_ibfk_4` FOREIGN KEY (`fkey_users_from_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_messages_ibfk_5` FOREIGN KEY (`fkey_users_to_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_messages_ibfk_6` FOREIGN KEY (`fkey_neighborhoods_id`) REFERENCES `neighborhoods` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_messages`
--

LOCK TABLES `user_messages` WRITE;
/*!40000 ALTER TABLE `user_messages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `user_messages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone_id` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` char(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `referral_code` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `referred_by` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `experience` int(11) NOT NULL DEFAULT '0',
  `level` int(11) NOT NULL DEFAULT '1',
  `last_access` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `fkey_neighborhoods_id` int(11) NOT NULL,
  `fkey_values_id` int(11) NOT NULL,
  `values` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `money` bigint(31) NOT NULL DEFAULT '500',
  `energy` int(11) NOT NULL DEFAULT '100',
  `energy_max` int(11) NOT NULL DEFAULT '100',
  `energy_next_gain` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `income` int(11) NOT NULL DEFAULT '0',
  `expenses` int(11) NOT NULL DEFAULT '0',
  `income_next_gain` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `actions` int(11) NOT NULL DEFAULT '3',
  `actions_max` int(11) NOT NULL DEFAULT '3',
  `actions_next_gain` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `initiative` int(11) NOT NULL DEFAULT '1',
  `endurance` int(11) NOT NULL DEFAULT '1',
  `elocution` int(11) NOT NULL DEFAULT '1',
  `debates_won` int(11) NOT NULL DEFAULT '0',
  `debates_lost` int(11) NOT NULL DEFAULT '0',
  `debates_last_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `favors_asked_noncompleted` int(11) NOT NULL DEFAULT '0',
  `favors_asked_completed` int(11) NOT NULL DEFAULT '0',
  `favors_noncompleted` int(11) NOT NULL DEFAULT '0',
  `favors_completed` int(11) NOT NULL DEFAULT '0',
  `last_bonus_date` date NOT NULL,
  `skill_points` int(11) NOT NULL DEFAULT '0',
  `luck` int(11) NOT NULL DEFAULT '10',
  `karma` int(11) NOT NULL DEFAULT '0',
  `seen_neighborhood_quests` tinyint(1) NOT NULL DEFAULT '0',
  `fkey_last_played_quest_groups_id` int(11) NOT NULL DEFAULT '0',
  `authKey` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_int` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone_id` (`phone_id`),
  KEY `fkey_neighborhoods_id` (`fkey_neighborhoods_id`),
  KEY `fkey_values_id` (`fkey_values_id`),
  KEY `fkey_last_played_quest_groups_id` (`fkey_last_played_quest_groups_id`),
  KEY `referral_code` (`referral_code`),
  KEY `debates_lost` (`debates_lost`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`fkey_neighborhoods_id`) REFERENCES `neighborhoods` (`id`),
  CONSTRAINT `users_ibfk_2` FOREIGN KEY (`fkey_last_played_quest_groups_id`) REFERENCES `quest_groups` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5560 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES (1,'abc123','Celestial Glory Game','abc123\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','USLCE','',464673,99,'2020-06-01 20:37:41',0,0,'Faith',11035836,2910,4560,'2020-06-01 20:39:36',8145,5074,'2020-06-01 21:00:00',10,15,'2020-06-01 20:40:23',1,1,18,418,11231,'2020-06-01 20:21:12',0,0,0,0,'2020-06-01',0,958,-85,1,1,'abc123','admin',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `values`
--

DROP TABLE IF EXISTS `values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) CHARACTER SET utf8 NOT NULL,
  `party_title` varchar(32) CHARACTER SET utf8 NOT NULL,
  `party_icon` varchar(32) CHARACTER SET utf8 NOT NULL,
  `color` char(6) CHARACTER SET utf8 NOT NULL,
  `slogan` varchar(64) CHARACTER SET utf8 NOT NULL,
  `fkey_neighborhoods_id` int(11) NOT NULL,
  `user_selectable` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fkey_neighborhoods_id` (`fkey_neighborhoods_id`),
  CONSTRAINT `values_ibfk_1` FOREIGN KEY (`fkey_neighborhoods_id`) REFERENCES `neighborhoods` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `values`
--

LOCK TABLES `values` WRITE;
/*!40000 ALTER TABLE `values` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `values` VALUES (0,'No Values','Neither Root Nor Branch','','','',11,0),(1,'Tradition','Jerusalemites','tradition','','Every one of us knows who he is and what God expects him to do.',1,1),(2,'Revelation','Lehites','revelation','','If I had not seen the things of God ... I should not have known ',1,1),(3,'Power','Desert Raiders','power','','The end justifies the means.',10,1),(4,'Pride','Babylonians','pride','','We are better than you.',6,1),(5,'Wealth','Merchants','wealth','','You can never have enough.',14,1);
/*!40000 ALTER TABLE `values` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `values_messages`
--

DROP TABLE IF EXISTS `values_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `values_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fkey_users_from_id` int(11) NOT NULL,
  `fkey_neighborhoods_id` int(11) NOT NULL,
  `fkey_values_id` int(11) NOT NULL,
  `message` varchar(512) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fkey_users_from_id` (`fkey_users_from_id`),
  KEY `fkey_users_to_id` (`fkey_neighborhoods_id`),
  KEY `fkey_values_id` (`fkey_values_id`),
  CONSTRAINT `values_messages_ibfk_1` FOREIGN KEY (`fkey_users_from_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `values_messages_ibfk_2` FOREIGN KEY (`fkey_neighborhoods_id`) REFERENCES `neighborhoods` (`id`) ON DELETE CASCADE,
  CONSTRAINT `values_messages_ibfk_3` FOREIGN KEY (`fkey_values_id`) REFERENCES `values` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `values_messages`
--

LOCK TABLES `values_messages` WRITE;
/*!40000 ALTER TABLE `values_messages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `values_messages` ENABLE KEYS */;
UNLOCK TABLES;
commit;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-06  9:02:32
